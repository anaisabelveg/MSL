package com.msl.principal;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.boot.MetadataSources;
import org.hibernate.boot.registry.StandardServiceRegistry;
import org.hibernate.boot.registry.StandardServiceRegistryBuilder;

import com.msl.persistencia.Alumno;
import com.msl.persistencia.Persona;
import com.msl.persistencia.Profesor;

public class AppMain {

	public static void main(String[] args) {
		// Hibernate 5
		StandardServiceRegistry registry = new StandardServiceRegistryBuilder().configure("hibernate.cfg.xml").build();
		SessionFactory sf = new MetadataSources(registry).buildMetadata().buildSessionFactory();

		Session session = sf.openSession();

		Transaction tx = session.getTransaction();

		// Crear las instancias de persona
		Persona persona = new Persona("1111111-A", "Juan", "Perez");

		Alumno alumno = new Alumno("2222222-B", "Maria", "Lopez", "Java");

		Profesor profesor = new Profesor("3333333-C", "Jorge", "Sanchez", "Ingeniero Informatico");

		try {
			tx.begin();

			session.persist(persona);
			session.persist(alumno);
			session.persist(profesor);

			tx.commit();
		} catch (Exception e) {
			tx.rollback();
			e.printStackTrace();
		} finally {
			// Cerramos la conexion
			session.close();
		}

	}

}
