package com.msl.principal;

import java.util.Date;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;

import com.msl.models.Direccion;
import com.msl.models.EstadoCivil;
import com.msl.persistencia.Persona;

public class AppMain {

	public static void main(String[] args) {
		// Cargar la unidad de persitencia
		EntityManagerFactory emf = Persistence.createEntityManagerFactory("PU");
		
		// Abrir una conexion
		EntityManager em = emf.createEntityManager();
		
		// Todas las persistencias necesitan una transaccion
		EntityTransaction et = em.getTransaction();
		
		// Crear las instancias de persona
		Persona p1 = new Persona("1111111-A", "Juan", 27, new Date("25/1/1965"), 'V', 
				new Direccion("Mayor", "Madrid", 28014), EstadoCivil.CASADO, 
				"Arquitecto, licenciado en la Complutense ......");
		
		Persona p2 = new Persona("2222222-B", "Maria", 51, new Date("2/11/1970"), 'H', 
				new Direccion("Castellana", "Madrid", 28016), EstadoCivil.DIVORCIADO, 
				"Doctora Ciencias Sociales, licenciado en la Complutense ......");
		
		Persona p3 = new Persona("3333333-C", "Jorge", 40, new Date("5/5/1981"), 'V', 
				new Direccion("Claudio Coello", "Madrid", 28112), EstadoCivil.SOLTERO, 
				"Ingeniero Informatico, licenciado en la Politecnica ......");
		
		try {
			et.begin();
			
			em.persist(p1);
			em.persist(p2);
			em.persist(p3);
			
			et.commit();
		} catch (Exception e) {
			et.rollback();
			e.printStackTrace();
		} finally {
			// Cerramos la conexion
			em.close();
		}
		

	}

}














