package com.msl.persistencia;

import javax.persistence.PostPersist;
import javax.persistence.PostRemove;
import javax.persistence.PostUpdate;
import javax.persistence.PrePersist;
import javax.persistence.PreRemove;
import javax.persistence.PreUpdate;

public class MiListener {
	
	@PrePersist
	@PreUpdate
	@PreRemove
	public void interceptar(Persona persona) {
		System.out.println("Interceptado " + persona);
		// Comprobaciones
		// Modificacion de datos
		// Eliminar espacios en blanco
		// Controbar la nulidad en algun campo
		// ..... 
		persona.setNombre(persona.getNombre().toUpperCase());
	}
	
	@PostPersist
	@PostRemove
	@PostUpdate
	public void ejecutado(Persona persona) {
		System.out.println("Operacion completada con " + persona);
	}

}
