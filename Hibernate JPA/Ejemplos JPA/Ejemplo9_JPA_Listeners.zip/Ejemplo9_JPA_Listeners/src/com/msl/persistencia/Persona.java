package com.msl.persistencia;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.*;

import com.msl.models.Direccion;
import com.msl.models.EstadoCivil;

// Una entidad debe cumplir:
// 1.- Tener una propiedad PK
// 2.- Constructor sin argumentos
// 3.- Todas las propiedades getter y setter
// 4.- Debe ser Serializable

@Entity
@EntityListeners(MiListener.class)
@Table(name="Ejemplo9_PERSONAS")
@SecondaryTable(name="Ejemplo9_CV", 
	pkJoinColumns= @PrimaryKeyJoinColumn(name="ID_NIF", referencedColumnName="ID_NIF"))

//@SecondaryTables({@SecondaryTable ......, @SecondaryTable ...., @SecondaryTable ....})
public class Persona implements Serializable {
	
	private static final long serialVersionUID = 1L;
	
	// Todas las PK deben ser de tipo clase, NUNCA tipo primitivo
	// para controlar null y valores unicos (equals y hascode)
	@Id
	@Column(name="ID_NIF", nullable=false)
	private String nif;
	
	private String nombre;
	private int edad;
	
	@Temporal(TemporalType.DATE)
	private Date fechaNacimiento;
	
	@Column(length=1)
	private char sexo;
	
	@Embedded
	private Direccion direccion;
	
	@Enumerated(EnumType.STRING)
	private EstadoCivil estado;
	
	// Carga LAZY (vaga), solo se carga em memoria getCv()
	// Carga EAGER (agil), cada vez que accedes a esta entidad te traes todos los datos
	@Lob
	@Basic(fetch=FetchType.LAZY)
	@Column(table="Ejemplo9_CV")
	private String cv;

	public Persona() {
		super();
	}
	
	public Persona(String nif, String nombre, int edad, Date fechaNacimiento, char sexo, Direccion direccion,
			EstadoCivil estado, String cv) {
		super();
		this.nif = nif;
		this.nombre = nombre;
		this.edad = edad;
		this.fechaNacimiento = fechaNacimiento;
		this.sexo = sexo;
		this.direccion = direccion;
		this.estado = estado;
		this.cv = cv;
	}

	public String getNif() {
		return nif;
	}
	
	public void setNif(String nif) {
		this.nif = nif;
	}

	public String getNombre() {
		return nombre;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	public int getEdad() {
		return edad;
	}

	public void setEdad(int edad) {
		this.edad = edad;
	}

	public Date getFechaNacimiento() {
		return fechaNacimiento;
	}

	public void setFechaNacimiento(Date fechaNacimiento) {
		this.fechaNacimiento = fechaNacimiento;
	}

	public char getSexo() {
		return sexo;
	}

	public void setSexo(char sexo) {
		this.sexo = sexo;
	}

	public Direccion getDireccion() {
		return direccion;
	}

	public void setDireccion(Direccion direccion) {
		this.direccion = direccion;
	}

	public EstadoCivil getEstado() {
		return estado;
	}

	public void setEstado(EstadoCivil estado) {
		this.estado = estado;
	}

	public String getCv() {
		return cv;
	}

	public void setCv(String cv) {
		this.cv = cv;
	}

	@Override
	public String toString() {
		return "Persona [nif=" + nif + ", nombre=" + nombre + ", edad=" + edad + ", fechaNacimiento=" + fechaNacimiento
				+ ", sexo=" + sexo + ", direccion=" + direccion + ", estado=" + estado + ", cv=" + cv + "]";
	}
	
	
   
}
