package com.msl.persistencia;

import javax.persistence.DiscriminatorValue;
import javax.persistence.Entity;
import javax.persistence.Table;

@Entity
@Table(name="Ejemplo5_PROFESORES")
@DiscriminatorValue(value="PROFE")
public class Profesor extends Persona{
	
	private String titulacion;
	
	public Profesor() {
		// TODO Auto-generated constructor stub
	}

	public Profesor(String nif, String nombre, String apellido, String titulacion) {
		super(nif, nombre, apellido);
		this.titulacion = titulacion;
	}

	public String getTitulacion() {
		return titulacion;
	}

	public void setTitulacion(String titulacion) {
		this.titulacion = titulacion;
	}

	@Override
	public String toString() {
		return "Profesor [titulacion=" + titulacion + ", toString()=" + super.toString() + "]";
	}
	
	

}
