package com.msl.persistencia;

import javax.persistence.DiscriminatorValue;
import javax.persistence.Entity;
import javax.persistence.Table;

@Entity
@Table(name="Ejemplo5_ALUMNOS")
@DiscriminatorValue(value="ALUM")
public class Alumno extends Persona{
	
	private String curso;
	
	public Alumno() {
		// TODO Auto-generated constructor stub
	}

	public Alumno(String nif, String nombre, String apellido, String curso) {
		super(nif, nombre, apellido);
		this.curso = curso;
	}

	public String getCurso() {
		return curso;
	}

	public void setCurso(String curso) {
		this.curso = curso;
	}

	@Override
	public String toString() {
		return "Alumno [curso=" + curso + ", toString()=" + super.toString() + "]";
	}

	
	
	

}
