package com.msl.principal;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;

import com.msl.persistencia.Alumno;
import com.msl.persistencia.Persona;
import com.msl.persistencia.Profesor;

public class AppMain {

	public static void main(String[] args) {
		// Cargar la unidad de persitencia
		EntityManagerFactory emf = Persistence.createEntityManagerFactory("PU");
		
		// Abrir una conexion
		EntityManager em = emf.createEntityManager();
		
		// Todas las persistencias necesitan una transaccion
		EntityTransaction et = em.getTransaction();
		
		// Crear las instancias de persona
		Persona persona = new Persona("1111111-A", "Juan", "Perez");
		
		Alumno alumno = new Alumno("2222222-B", "Maria", "Lopez", "Java");
		
		Profesor profesor= new Profesor("3333333-C", "Jorge", "Sanchez", "Ingeniero Informatico");
		
		try {
			et.begin();
			
			em.persist(persona);
			em.persist(alumno);
			em.persist(profesor);
			
			et.commit();
		} catch (Exception e) {
			et.rollback();
			e.printStackTrace();
		} finally {
			// Cerramos la conexion
			em.close();
		}
		

	}

}














