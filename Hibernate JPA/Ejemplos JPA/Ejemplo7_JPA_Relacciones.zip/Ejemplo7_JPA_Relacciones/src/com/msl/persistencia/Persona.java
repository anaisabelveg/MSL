package com.msl.persistencia;

import java.io.Serializable;
import java.util.HashSet;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.Table;


@Entity
@Table(name="Ejemplo7_PERSONAS")
public class Persona implements Serializable {
	
	private static final long serialVersionUID = 1L;
	
	
	@Id
	@Column(name="ID_PERSONA", nullable=false)
	@GeneratedValue(strategy=GenerationType.SEQUENCE)
	private Long id;
	
	private String nombre;
	
	@OneToOne(cascade = CascadeType.ALL)
	@JoinColumn(name="NIF_ID", referencedColumnName="ID_NIF")
	private Nif nif;
	
	@OneToMany(mappedBy="persona", cascade=CascadeType.ALL)
	private Set<Telefono> telefonos = new HashSet<>();
	
	@ManyToMany(cascade = {CascadeType.DETACH, CascadeType.MERGE, CascadeType.PERSIST, CascadeType.REFRESH})
	@JoinTable(name="EJEMPLO7_Personas_Coches",
			joinColumns=@JoinColumn(name="ID_PERSONA", referencedColumnName="ID_PERSONA"),
			inverseJoinColumns=@JoinColumn(name="ID_COCHE", referencedColumnName="ID_COCHE"))
	private Set<Coche> coches = new HashSet<>();
	
	public Persona() {
		super();
	}

	public Persona(String nombre, Nif nif) {
		super();
		this.nombre = nombre;
		this.nif = nif;
	}
	
	// Metodos de sincroniacion
	// Uno por cada propiedad de tipo colecction
	public void addTelefono(Telefono telefono) {
		telefonos.add(telefono);
		telefono.setPersona(this);
	}
	
	public void addCoche(Coche coche) {
		coches.add(coche);
		coche.getPropietarios().add(this);
	}
	

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getNombre() {
		return nombre;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	public Nif getNif() {
		return nif;
	}

	public void setNif(Nif nif) {
		this.nif = nif;
	}

	public Set<Telefono> getTelefonos() {
		return telefonos;
	}

	public void setTelefonos(Set<Telefono> telefonos) {
		this.telefonos = telefonos;
	}

	public Set<Coche> getCoches() {
		return coches;
	}

	public void setCoches(Set<Coche> coches) {
		this.coches = coches;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((nif == null) ? 0 : nif.hashCode());
		result = prime * result + ((nombre == null) ? 0 : nombre.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Persona other = (Persona) obj;
		if (nif == null) {
			if (other.nif != null)
				return false;
		} else if (!nif.equals(other.nif))
			return false;
		if (nombre == null) {
			if (other.nombre != null)
				return false;
		} else if (!nombre.equals(other.nombre))
			return false;
		return true;
	}

	@Override
	public String toString() {
		return "Persona [id=" + id + ", nombre=" + nombre + ", nif=" + nif + ", telefonos=" + telefonos + ", coches="
				+ coches + "]";
	}
	
	
	
	
	
}