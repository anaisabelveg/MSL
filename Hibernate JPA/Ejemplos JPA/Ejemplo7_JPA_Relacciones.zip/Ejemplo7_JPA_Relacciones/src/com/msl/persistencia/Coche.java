package com.msl.persistencia;

import java.io.Serializable;
import java.util.HashSet;
import java.util.Set;

import javax.persistence.*;

/**
 * Entity implementation class for Entity: Coche
 *
 */
@Entity
@Table(name="Ejemplo7_Coches")
public class Coche implements Serializable {

	
	private static final long serialVersionUID = 1L;
	
	@Id
	@Column(name="ID_COCHE", nullable=false)
	@GeneratedValue(strategy=GenerationType.SEQUENCE)
	private Long id;
	
	private String matricula;
	private String modelo;
	
	@ManyToMany(mappedBy="coches",
			cascade = {CascadeType.DETACH, CascadeType.MERGE, CascadeType.PERSIST, CascadeType.REFRESH})
	private Set<Persona> propietarios = new HashSet<>();

	public Coche() {
		super();
	}

	public Coche(String matricula, String modelo) {
		super();
		this.matricula = matricula;
		this.modelo = modelo;
	}
	
	// Metodo de sincronizacion
	public void addPropietario(Persona propietario) {
		propietarios.add(propietario);
		propietario.getCoches().add(this);
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getMatricula() {
		return matricula;
	}

	public void setMatricula(String matricula) {
		this.matricula = matricula;
	}

	public String getModelo() {
		return modelo;
	}

	public void setModelo(String modelo) {
		this.modelo = modelo;
	}

	public Set<Persona> getPropietarios() {
		return propietarios;
	}

	public void setPropietarios(Set<Persona> propietarios) {
		this.propietarios = propietarios;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((matricula == null) ? 0 : matricula.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Coche other = (Coche) obj;
		if (matricula == null) {
			if (other.matricula != null)
				return false;
		} else if (!matricula.equals(other.matricula))
			return false;
		return true;
	}

	@Override
	public String toString() {
		return "Coche [matricula=" + matricula + ", modelo=" + modelo + "]";
	}
	
	
   
}
