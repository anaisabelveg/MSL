package com.msl.persistencia;

import java.io.Serializable;
import javax.persistence.*;

/**
 * Entity implementation class for Entity: Telefono
 *
 */
@Entity
@Table(name="Ejemplo7_Telefonos")
public class Telefono implements Serializable {

	
	private static final long serialVersionUID = 1L;
	
	@Id
	@Column(name="ID_TELEFONO", nullable=false)
	@GeneratedValue(strategy=GenerationType.SEQUENCE)
	private Long id;
	
	private long telefono;
	
	@ManyToOne    // La entidad princial es la que contiene el ManyToOne
	@JoinColumn(name="PERSONA_ID", referencedColumnName="ID_PERSONA")
	private Persona persona;

	public Telefono() {
		super();
	}

	public Telefono(long telefono) {
		super();
		this.telefono = telefono;
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public long getTelefono() {
		return telefono;
	}

	public void setTelefono(long telefono) {
		this.telefono = telefono;
	}

	public Persona getPersona() {
		return persona;
	}

	public void setPersona(Persona persona) {
		this.persona = persona;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + (int) (telefono ^ (telefono >>> 32));
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Telefono other = (Telefono) obj;
		if (telefono != other.telefono)
			return false;
		return true;
	}

	@Override
	public String toString() {
		return "Telefono [telefono=" + telefono + "]";
	}
	
	
   
}
