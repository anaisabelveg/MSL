package com.msl.principal;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;

import com.msl.persistencia.Coche;
import com.msl.persistencia.Nif;
import com.msl.persistencia.Persona;
import com.msl.persistencia.Telefono;

public class AppMain {

	public static void main(String[] args) {
		// Cargar la unidad de persitencia
		EntityManagerFactory emf = Persistence.createEntityManagerFactory("PU");
		
		// Abrir una conexion
		EntityManager em = emf.createEntityManager();
		
		// Todas las persistencias necesitan una transaccion
		EntityTransaction et = em.getTransaction();
		
		
		// Crear las instancias de persona
		Persona p1 = new Persona("Juan", new Nif(11111111L,'A'));		
		Persona p2 = new Persona("Maria", new Nif(22222222L,'B'));	
		Persona p3 = new Persona("Jorge", new Nif(33333333L,'C'));
		
		// Crear los telefonos
		Telefono t1 = new Telefono(656111111L);
		Telefono t2 = new Telefono(656222222L);
		Telefono t3 = new Telefono(656333333L);
		Telefono t4 = new Telefono(656444444L);
		Telefono t5 = new Telefono(656555555L);
		Telefono t6 = new Telefono(656666666L);
		
		// Crear los coches
		Coche c1 = new Coche("1234-HGD", "A3");
		Coche c2 = new Coche("9999-HGD", "A4");
		Coche c3 = new Coche("7777-HGD", "A5");
		Coche c4 = new Coche("4444-HGD", "A6");
		
		// Asignar los telefonos
		p1.addTelefono(t1);
		p1.addTelefono(t2);
		p2.addTelefono(t3);
		p2.addTelefono(t4);
		p3.addTelefono(t5);
		p3.addTelefono(t6);
		
		// Asignar los coches
		p1.addCoche(c1);
		p1.addCoche(c2);
		p1.addCoche(c3);
		
		p2.addCoche(c2);
		p2.addCoche(c3);
		p2.addCoche(c4);
		
		p3.addCoche(c1);
		p3.addCoche(c4);
		
		try {
			et.begin();
			
			em.persist(p1);
			em.persist(p2);
			em.persist(p3);
			
			et.commit();
			
			System.out.println(p1);
			System.out.println(p2);
			System.out.println(p3);
		} catch (Exception e) {
			et.rollback();
			e.printStackTrace();
		} finally {
			// Cerramos la conexion
			em.close();
		}
		

	}

}














