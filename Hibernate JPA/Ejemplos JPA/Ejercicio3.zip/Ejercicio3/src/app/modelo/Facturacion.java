/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package app.modelo;

import java.io.Serializable;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToOne;
import javax.persistence.Table;

/**
 *
 * @author profesor
 */
@Entity
@Table(name="ejercicio3_facturaciones")
public class Facturacion implements Serializable {

    private static final long serialVersionUID = 1L;
    @Id
    @Column(name="ID_FACTURACION")
    @GeneratedValue(strategy = GenerationType.SEQUENCE)
    private Long id;
    
    private int sueldo;
    private int publicidad;

    @OneToOne(mappedBy="facturacion")
    private Piloto piloto;

    public Facturacion(int sueldo, int publicidad) {
        this.sueldo = sueldo;
        this.publicidad = publicidad;
    }

    public Facturacion() {
    }

    public void addPiloto(Piloto p){
        setPiloto(p);
        p.setFacturacion(this);
    }

    public Piloto getPiloto() {
        return piloto;
    }

    public void setPiloto(Piloto piloto) {
        this.piloto = piloto;
        
    }

    public int getPublicidad() {
        return publicidad;
    }

    public void setPublicidad(int publicidad) {
        this.publicidad = publicidad;
    }

    public int getSueldo() {
        return sueldo;
    }

    public void setSueldo(int sueldo) {
        this.sueldo = sueldo;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    
    @Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((piloto == null) ? 0 : piloto.hashCode());
		result = prime * result + publicidad;
		result = prime * result + sueldo;
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Facturacion other = (Facturacion) obj;
		if (piloto == null) {
			if (other.piloto != null)
				return false;
		} else if (!piloto.equals(other.piloto))
			return false;
		if (publicidad != other.publicidad)
			return false;
		if (sueldo != other.sueldo)
			return false;
		return true;
	}

	@Override
    public String toString() {
        return "Facturacion{" + "sueldo=" + sueldo + "publicidad=" + publicidad + '}';
    }
}
