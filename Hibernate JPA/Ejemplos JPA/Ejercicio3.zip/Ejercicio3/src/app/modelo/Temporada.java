/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package app.modelo;

import java.io.Serializable;
import java.util.HashSet;
import java.util.Set;
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToMany;
import javax.persistence.Table;

/**
 *
 * @author profesor
 */
@Entity
@Table(name="ejercicio3_temporadas")
public class Temporada implements Serializable {
    private static final long serialVersionUID = 1L;
    @Id
    @Column(name="ID_TEMPORADA")
    @GeneratedValue(strategy = GenerationType.SEQUENCE)
    private Long id;

    private int inicio;
    private int fin;

    @ManyToMany(mappedBy="temporadas",
                cascade={CascadeType.MERGE,CascadeType.PERSIST,
                         CascadeType.REFRESH, CascadeType.DETACH})
    private Set<Piloto> pilotos = new HashSet<Piloto>();

    public Temporada() {
    }

    public Temporada(int inicio, int fin) {
        this.inicio = inicio;
        this.fin = fin;
    }

    public void addPiloto(Piloto p){
        pilotos.add(p);
        p.getTemporadas().add(this);
    }

    public int getFin() {
        return fin;
    }

    public void setFin(int fin) {
        this.fin = fin;
    }

    public int getInicio() {
        return inicio;
    }

    public void setInicio(int inicio) {
        this.inicio = inicio;
    }

    public Set<Piloto> getPilotos() {
        return pilotos;
    }

    public void setPilotos(Set<Piloto> pilotos) {
        this.pilotos = pilotos;
    }


    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (id != null ? id.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object obj) {
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final Temporada other = (Temporada) obj;
        if (this.id != other.id && (this.id == null || !this.id.equals(other.id))) {
            return false;
        }
        if (this.inicio != other.inicio) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "Temporada{" + "inicio=" + inicio + "fin=" + fin + '}';
    }

    

    

}
