/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package app.modelo;

import java.io.Serializable;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToOne;
import javax.persistence.Table;

/**
 *
 * @author profesor
 */
@Entity
@Table(name="ejercicio3_nifs")
public class Nif implements Serializable {

    private static final long serialVersionUID = 1L;
    
    @Id
    @Column(name="ID_NIF")
    @GeneratedValue(strategy = GenerationType.SEQUENCE)
    private Long id;

    private char letra;
    
    private long numero;
    
    @OneToOne(mappedBy="nif")
    private Piloto piloto;

    public Nif() {
    }

    public Nif(char letra, long numero) {
        this.letra = letra;
        this.numero = numero;
    }

    public Piloto getPiloto() {
		return piloto;
	}
    
    public void setPiloto(Piloto piloto) {
		this.piloto = piloto;
	}
    
    public char getLetra() {
        return letra;
    }

    public void setLetra(char letra) {
        this.letra = letra;
    }

    public long getNumero() {
        return numero;
    }

    public void setNumero(long numero) {
        this.numero = numero;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

   

    @Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + letra;
		result = prime * result + (int) (numero ^ (numero >>> 32));
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Nif other = (Nif) obj;
		if (letra != other.letra)
			return false;
		if (numero != other.numero)
			return false;
		return true;
	}

	@Override
    public String toString() {
        return "Nif{" + "letra=" + letra + "numero=" + numero + '}';
    }
}
