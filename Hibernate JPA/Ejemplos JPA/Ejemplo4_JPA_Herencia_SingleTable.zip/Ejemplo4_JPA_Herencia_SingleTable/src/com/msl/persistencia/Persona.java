package com.msl.persistencia;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.DiscriminatorColumn;
import javax.persistence.DiscriminatorType;
import javax.persistence.DiscriminatorValue;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Inheritance;
import javax.persistence.InheritanceType;
import javax.persistence.Table;


@Entity
@Table(name="Ejemplo4_PERSONAS")
@Inheritance(strategy= InheritanceType.SINGLE_TABLE)
@DiscriminatorColumn(name="TIPO", discriminatorType=DiscriminatorType.STRING)
@DiscriminatorValue(value="PER")
public class Persona implements Serializable {
	
	private static final long serialVersionUID = 1L;
	
	// Todas las PK deben ser de tipo clase, NUNCA tipo primitivo
	// para controlar null y valores unicos (equals y hascode)
	@Id
	@Column(name="ID_NIF", nullable=false)
	private String nif;
	
	private String nombre;
	private String apellido;
	
	public Persona() {
		super();
	}

	public Persona(String nif, String nombre, String apellido) {
		super();
		this.nif = nif;
		this.nombre = nombre;
		this.apellido = apellido;
	}

	public String getNif() {
		return nif;
	}

	public void setNif(String nif) {
		this.nif = nif;
	}

	public String getNombre() {
		return nombre;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	public String getApellido() {
		return apellido;
	}

	public void setApellido(String apellido) {
		this.apellido = apellido;
	}

	@Override
	public String toString() {
		return "Persona [nif=" + nif + ", nombre=" + nombre + ", apellido=" + apellido + "]";
	}
	
	
   
}
