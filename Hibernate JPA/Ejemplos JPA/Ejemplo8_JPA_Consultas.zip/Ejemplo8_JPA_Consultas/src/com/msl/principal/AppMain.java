package com.msl.principal;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.Query;

import com.msl.persistencia.Persona;

public class AppMain {

	public static void main(String[] args) {
		// Cargar la unidad de persitencia
		EntityManagerFactory emf = Persistence.createEntityManagerFactory("PU");
		
		// Abrir una conexion
		EntityManager em = emf.createEntityManager();
		
		// 1.- Lectura por PK
		String nif = "1111111-A";
		Persona juan = em.find(Persona.class, nif);
		//System.out.println(juan);
		
		// PK Compuesta
		// PedidoPK pedidoPK = new PedidoPK("numpedido","numproducto");
		// Pedido pedido = em.find(Pedido.class, pedidoPK);
		
		// 2.- Consulta por JPQL
		Query q1 = em.createQuery("select p from Persona p");
		List<Persona> todas = q1.getResultList();
		for (Persona persona : todas) {
			//System.out.println(persona);
		}
		
		// Query con parametros buscando CV de la Complutense
		q1 = em.createQuery("select p from Persona p where p.cv like :uni ");
		q1.setParameter("uni", "%Complutense%");
		todas = q1.getResultList();
		for (Persona persona : todas) {
			//System.out.println(persona);
		}
		
		// 3.- Consulta a través de NamedQuery
		Query q2 = em.createNamedQuery("nombre");
		q2.setParameter("nom", "Maria");
		Persona maria = (Persona) q2.getSingleResult();
		//System.out.println(maria);
		
		q2 = em.createNamedQuery("chicas");
		q2.setParameter("sex", 'H');
		todas = q1.getResultList();
		for (Persona persona : todas) {
			System.out.println(persona);
		}

	}

}
