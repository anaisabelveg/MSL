package com.msl.persistencia;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.*;

import com.msl.models.Direccion;
import com.msl.models.EstadoCivil;


@Entity
@IdClass(PedidoPK.class)
@Table(name="Ejemplo2_PEDIDOS")
public class Pedido implements Serializable {
	
	private static final long serialVersionUID = 1L;
	
	// Todas las PK deben ser de tipo clase, NUNCA tipo primitivo
	// para controlar null y valores unicos (equals y hascode)
	@Id
	@Column(name="ID_NUM_PEDIDO", nullable=false)
	private String numPedido;
	
	@Id
	@Column(name="ID_PRODUCTO", nullable=false)
	private String idProducto;
	
	
	private String descripcion;
	private int cantidad;
	
	public Pedido() {
		// TODO Auto-generated constructor stub
	}

	public Pedido(String numPedido, String idProducto, String descripcion, int cantidad) {
		super();
		this.numPedido = numPedido;
		this.idProducto = idProducto;
		this.descripcion = descripcion;
		this.cantidad = cantidad;
	}

	public String getNumPedido() {
		return numPedido;
	}

	public void setNumPedido(String numPedido) {
		this.numPedido = numPedido;
	}

	public String getIdProducto() {
		return idProducto;
	}

	public void setIdProducto(String idProducto) {
		this.idProducto = idProducto;
	}

	public String getDescripcion() {
		return descripcion;
	}

	public void setDescripcion(String descripcion) {
		this.descripcion = descripcion;
	}

	public int getCantidad() {
		return cantidad;
	}

	public void setCantidad(int cantidad) {
		this.cantidad = cantidad;
	}

	@Override
	public String toString() {
		return "Pedido [numPedido=" + numPedido + ", idProducto=" + idProducto + ", descripcion=" + descripcion
				+ ", cantidad=" + cantidad + "]";
	}
	
	
	
}
