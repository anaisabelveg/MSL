package com.msl.persistencia;

import java.io.Serializable;

import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.Table;


@Entity
@Table(name="Ejemplo3_PEDIDOS")
public class Pedido implements Serializable {
	
	private static final long serialVersionUID = 1L;
	
	@EmbeddedId
	private PedidoPK pedidoPK;
		
	private String descripcion;
	private int cantidad;
	
	public Pedido() {
		// TODO Auto-generated constructor stub
	}

	public Pedido(PedidoPK pedidoPK, String descripcion, int cantidad) {
		super();
		this.pedidoPK = pedidoPK;
		this.descripcion = descripcion;
		this.cantidad = cantidad;
	}

	public PedidoPK getPedidoPK() {
		return pedidoPK;
	}

	public void setPedidoPK(PedidoPK pedidoPK) {
		this.pedidoPK = pedidoPK;
	}

	public String getDescripcion() {
		return descripcion;
	}

	public void setDescripcion(String descripcion) {
		this.descripcion = descripcion;
	}

	public int getCantidad() {
		return cantidad;
	}

	public void setCantidad(int cantidad) {
		this.cantidad = cantidad;
	}

	@Override
	public String toString() {
		return "Pedido [pedidoPK=" + pedidoPK + ", descripcion=" + descripcion + ", cantidad=" + cantidad + "]";
	}
	
}
