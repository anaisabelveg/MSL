package com.msl.persistencia;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Embeddable;
import javax.persistence.Id;

@Embeddable
public class PedidoPK implements Serializable{
	
	@Column(name="ID_NUM_PEDIDO", nullable=false)
	private String numPedido;
	
	@Column(name="ID_PRODUCTO", nullable=false)
	private String idProducto;
	
	public PedidoPK() {
		// TODO Auto-generated constructor stub
	}

	public PedidoPK(String numPedido, String idProducto) {
		super();
		this.numPedido = numPedido;
		this.idProducto = idProducto;
	}

	public String getNumPedido() {
		return numPedido;
	}

	public void setNumPedido(String numPedido) {
		this.numPedido = numPedido;
	}

	public String getIdProducto() {
		return idProducto;
	}

	public void setIdProducto(String idProducto) {
		this.idProducto = idProducto;
	}

	@Override
	public String toString() {
		return "PedidoPK [numPedido=" + numPedido + ", idProducto=" + idProducto + "]";
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((idProducto == null) ? 0 : idProducto.hashCode());
		result = prime * result + ((numPedido == null) ? 0 : numPedido.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		PedidoPK other = (PedidoPK) obj;
		if (idProducto == null) {
			if (other.idProducto != null)
				return false;
		} else if (!idProducto.equals(other.idProducto))
			return false;
		if (numPedido == null) {
			if (other.numPedido != null)
				return false;
		} else if (!numPedido.equals(other.numPedido))
			return false;
		return true;
	}

	
	
	

}
