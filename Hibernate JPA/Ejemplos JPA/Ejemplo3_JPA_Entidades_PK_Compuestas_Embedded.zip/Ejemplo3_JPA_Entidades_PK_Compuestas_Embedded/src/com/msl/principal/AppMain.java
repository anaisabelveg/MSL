package com.msl.principal;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;

import com.msl.persistencia.Pedido;
import com.msl.persistencia.PedidoPK;

public class AppMain {

	public static void main(String[] args) {
		// Cargar la unidad de persitencia
		EntityManagerFactory emf = Persistence.createEntityManagerFactory("PU");
		
		// Abrir una conexion
		EntityManager em = emf.createEntityManager();
		
		// Todas las persistencias necesitan una transaccion
		EntityTransaction et = em.getTransaction();
		
		// Crear las instancias de persona
		Pedido p1 = new Pedido(new PedidoPK("Ped1", "Produ1"), "Libro", 5);
		
		Pedido p2 = new Pedido(new PedidoPK("Ped1", "Produ2"), "Cuaderno", 10);
		
		Pedido p3 = new Pedido(new PedidoPK("Ped2", "Produ1"), "Lapiz", 50);
		
		try {
			et.begin();
			
			em.persist(p1);
			em.persist(p2);
			em.persist(p3);
			
			et.commit();
		} catch (Exception e) {
			et.rollback();
			e.printStackTrace();
		} finally {
			// Cerramos la conexion
			em.close();
		}
		

	}

}














