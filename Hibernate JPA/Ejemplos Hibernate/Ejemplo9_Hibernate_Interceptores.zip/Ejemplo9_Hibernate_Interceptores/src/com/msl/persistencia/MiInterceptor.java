package com.msl.persistencia;

import java.io.Serializable;

import org.hibernate.EmptyInterceptor;
import org.hibernate.type.Type;

public class MiInterceptor extends EmptyInterceptor{
	
	@Override
	public boolean onSave(Object entity,   // Entidad a persistir
						  Serializable id, // PK
						  Object[] state, // Valores de la entidad
						  String[] propertyNames, //nombres de las propiedades
						  Type[] types) {   //tipos de las propiedades
		
		System.out.println("Entidad: " + entity);
		System.out.println("PK: " + id);
		System.out.println("Propiedades: ");
		for(int i=0; i< propertyNames.length; i++) {
			System.out.println(propertyNames[i] + ": " + " tipo " + types[i] + " valor " + state[i]);
		}
		
		// si devuelve true, los cambios en el estado se aplican
		// si devuelve false, todo cambio realizado no se aplica
		return true;
	}

}
