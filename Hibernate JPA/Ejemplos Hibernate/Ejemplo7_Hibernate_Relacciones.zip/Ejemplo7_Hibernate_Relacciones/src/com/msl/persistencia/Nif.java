package com.msl.persistencia;

import java.io.Serializable;

/**
 * Entity implementation class for Entity: Nif
 *
 */

public class Nif implements Serializable {

	
	private static final long serialVersionUID = 1L;
	
	private Long id;	
	private long numero;
	private char letra;
	private Persona persona;
	
	public Nif() {
		super();
	}

	public Nif(long numero, char letra) {
		super();
		this.numero = numero;
		this.letra = letra;
	}

	public Persona getPersona() {
		return persona;
	}
	
	public void setPersona(Persona persona) {
		this.persona = persona;
	}

	public Long getId() {
		return id;
	}


	public void setId(Long id) {
		this.id = id;
	}


	public long getNumero() {
		return numero;
	}


	public void setNumero(long numero) {
		this.numero = numero;
	}


	public char getLetra() {
		return letra;
	}


	public void setLetra(char letra) {
		this.letra = letra;
	}


	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + letra;
		result = prime * result + (int) (numero ^ (numero >>> 32));
		return result;
	}


	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Nif other = (Nif) obj;
		if (letra != other.letra)
			return false;
		if (numero != other.numero)
			return false;
		return true;
	}


	@Override
	public String toString() {
		return "Nif [numero=" + numero + ", letra=" + letra + "]";
	}
	
	
   
}
