package com.msl.persistencia;

import java.io.Serializable;


public class Pedido implements Serializable {
	
	private static final long serialVersionUID = 1L;
	
	private String numPedido;
	private String idProducto;
	private String descripcion;
	private int cantidad;
	
	public Pedido() {
		// TODO Auto-generated constructor stub
	}

	public Pedido(String numPedido, String idProducto, String descripcion, int cantidad) {
		super();
		this.numPedido = numPedido;
		this.idProducto = idProducto;
		this.descripcion = descripcion;
		this.cantidad = cantidad;
	}

	public String getNumPedido() {
		return numPedido;
	}

	public void setNumPedido(String numPedido) {
		this.numPedido = numPedido;
	}

	public String getIdProducto() {
		return idProducto;
	}

	public void setIdProducto(String idProducto) {
		this.idProducto = idProducto;
	}

	public String getDescripcion() {
		return descripcion;
	}

	public void setDescripcion(String descripcion) {
		this.descripcion = descripcion;
	}

	public int getCantidad() {
		return cantidad;
	}

	public void setCantidad(int cantidad) {
		this.cantidad = cantidad;
	}

	@Override
	public String toString() {
		return "Pedido [numPedido=" + numPedido + ", idProducto=" + idProducto + ", descripcion=" + descripcion
				+ ", cantidad=" + cantidad + "]";
	}
	
	
	
}
