package com.msl.principal;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.boot.MetadataSources;
import org.hibernate.boot.registry.StandardServiceRegistry;
import org.hibernate.boot.registry.StandardServiceRegistryBuilder;

import com.msl.persistencia.Pedido;

public class AppMain {

	public static void main(String[] args) {
		// Hibernate 5
		StandardServiceRegistry registry = new StandardServiceRegistryBuilder().configure("hibernate.cfg.xml").build();
		SessionFactory sf = new MetadataSources(registry).buildMetadata().buildSessionFactory();

		Session session = sf.openSession();

		Transaction tx = session.getTransaction();

		// Crear las instancias de persona
		Pedido p1 = new Pedido("Ped1", "Produ1", "Libro", 5);

		Pedido p2 = new Pedido("Ped1", "Produ2", "Cuaderno", 10);

		Pedido p3 = new Pedido("Ped2", "Produ1", "Lapiz", 50);

		try {
			tx.begin();

			session.persist(p1);
			session.persist(p2);
			session.persist(p3);

			tx.commit();
		} catch (Exception e) {
			tx.rollback();
			e.printStackTrace();
		} finally {
			// Cerramos la conexion
			session.close();
		}

	}

}
