package com.msl.models;

public enum EstadoCivil {
	SOLTERO,CASADO,VIUDO,DIVORCIADO
}
