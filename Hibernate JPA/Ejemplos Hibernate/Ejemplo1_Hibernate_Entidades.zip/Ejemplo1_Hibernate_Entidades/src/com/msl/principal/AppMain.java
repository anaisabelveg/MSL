package com.msl.principal;

import java.util.Date;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.boot.MetadataSources;
import org.hibernate.boot.registry.StandardServiceRegistry;
import org.hibernate.boot.registry.StandardServiceRegistryBuilder;

import com.msl.models.Direccion;
import com.msl.models.EstadoCivil;
import com.msl.persistencia.Persona;

public class AppMain {

	public static void main(String[] args) {
		// Deprecated en Hibernate 4
		// SessionFactory sf = new
		// Configuration().configure().buildSessionFactory();

		// Ahora la recomendacion es esta
		// Configuration configuration = new
		// Configuration().configure("hibernate.cfg.xml");
		// StandardServiceRegistryBuilder builder =
		// new
		// StandardServiceRegistryBuilder().applySettings(configuration.getProperties());
		// SessionFactory sf =
		// configuration.buildSessionFactory(builder.build());

		// Hibernate 5
		StandardServiceRegistry registry = new StandardServiceRegistryBuilder().configure("hibernate.cfg.xml").build();
		SessionFactory sf = new MetadataSources(registry).buildMetadata().buildSessionFactory();

		Session session = sf.openSession();

		Transaction tx = session.getTransaction();

		// Crear las instancias de persona
		Persona p1 = new Persona("1111111-A", "Juan", 27, new Date("25/1/1965"), 'V',
				new Direccion("Mayor", "Madrid", 28014), EstadoCivil.CASADO,
				"Arquitecto, licenciado en la Complutense ......");

		Persona p2 = new Persona("2222222-B", "Maria", 51, new Date("2/11/1970"), 'H',
				new Direccion("Castellana", "Madrid", 28016), EstadoCivil.DIVORCIADO,
				"Doctora Ciencias Sociales, licenciado en la Complutense ......");

		Persona p3 = new Persona("3333333-C", "Jorge", 40, new Date("5/5/1981"), 'V',
				new Direccion("Claudio Coello", "Madrid", 28112), EstadoCivil.SOLTERO,
				"Ingeniero Informatico, licenciado en la Politecnica ......");

		try {
			tx.begin();

			session.persist(p1);
			session.persist(p2);
			session.persist(p3);

			tx.commit();
		} catch (Exception e) {
			tx.rollback();
			e.printStackTrace();
		} finally {
			// Cerramos la conexion
			session.close();
		}

	}

}
