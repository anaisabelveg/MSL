package com.msl.principal;

import java.util.Date;
import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.boot.MetadataSources;
import org.hibernate.boot.registry.StandardServiceRegistry;
import org.hibernate.boot.registry.StandardServiceRegistryBuilder;
import org.hibernate.query.Query;

import com.msl.models.Direccion;
import com.msl.models.EstadoCivil;
import com.msl.persistencia.Persona;

public class AppMain {

	public static void main(String[] args) {
		
		// Hibernate 5
		StandardServiceRegistry registry = new StandardServiceRegistryBuilder().configure("hibernate.cfg.xml").build();
		SessionFactory sf = new MetadataSources(registry).buildMetadata().buildSessionFactory();

		Session session = sf.openSession();

		// Crear las instancias de persona
		Persona p1 = new Persona("1111111-A", "Juan", 27, new Date("25/1/1965"), 'V',
				new Direccion("Mayor", "Madrid", 28014), EstadoCivil.CASADO,
				"Arquitecto, licenciado en la Complutense ......");

		Persona p2 = new Persona("2222222-B", "Maria", 51, new Date("2/11/1970"), 'H',
				new Direccion("Castellana", "Madrid", 28016), EstadoCivil.DIVORCIADO,
				"Doctora Ciencias Sociales, licenciado en la Complutense ......");

		Persona p3 = new Persona("3333333-C", "Jorge", 40, new Date("5/5/1981"), 'V',
				new Direccion("Claudio Coello", "Madrid", 28112), EstadoCivil.SOLTERO,
				"Ingeniero Informatico, licenciado en la Politecnica ......");

		// 1.- Buscar por pk
		System.out.println("--------------- Buscar por PK --------------");
		Persona juan = session.get(Persona.class, "1111111-A");
		System.out.println(juan);
		
		// 2.- Consultas con HQL
		System.out.println("--------------- Consulta con HQL --------------");
		Query<Persona> q1 = session.createQuery("from Persona p");
		List<Persona> todas = q1.list();
		for (Persona persona : todas) {
			System.out.println(persona);
		}
		
		// 3.- Consultas con HQL con parametros
		System.out.println("--------------- Consulta con HQL con parametros --------------");
		Query<Persona> q2 = session.createQuery("from Persona p where p.direccion.poblacion = :ciudad");
		q2.setParameter("ciudad", "Madrid");
		List<Persona> madrilenos = q2.list();
		for (Persona persona : madrilenos) {
				System.out.println(persona);
		}
		
		// 4.- Consultas por NamedQuery
		System.out.println("--------------- Consulta con NamedQuery --------------");
		Query<Persona> q3 = session.getNamedQuery("vacunados");
		q3.setParameter("anyos", 45);
		Persona vacunado = q3.getSingleResult();
		System.out.println(vacunado);
		
	}

}






