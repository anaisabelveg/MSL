package com.msl.cliente;

import com.msl.modelos.Producto;
import com.msl.negocio.ItfzNegocioProductos;
import com.msl.negocio.NegocioProductos;

public class AppMain {

	public static void main(String[] args) {
		
		ItfzNegocioProductos negocio = new NegocioProductos();
		
		System.out.println("Todos los productos");
		System.out.println("-------------------");
		for(Producto producto : negocio.consultarTodos()) {
			System.out.println(producto);
		}
		
		System.out.println("Insertado producto");
		System.out.println("------------------");
		System.out.println(negocio.insertarNuevo(new Producto(8,"Ipa",2.1)));
		
		System.out.println("Buscar producto");
		System.out.println("------------------");
		System.out.println(negocio.buscar(3));
		
		System.out.println("Eliminar producto");
		System.out.println("------------------");
		System.out.println(negocio.eliminarProducto(8));
		
		System.out.println("Modificar producto");
		System.out.println("------------------");
		System.out.println(negocio.modificarPrecio(3, 4.5));


	}

}
