package com.msl.persistencia;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import com.msl.modelos.Producto;

public class ProductosDAO implements ItfzProductosDAO {
	
	private Connection conexion;

	@Override
	public List<Producto> consultarTodos() {
		List<Producto> lista = new ArrayList<>();
		try {
			abrirConexion();
			Statement stm = conexion.createStatement();
			ResultSet rs = stm.executeQuery("select * from productos");
			while(rs.next()) {
				lista.add(new Producto(rs.getInt("ID"), rs.getString("DESCRIPCION"), rs.getDouble("PRECIO")));
			}
		} catch (SQLException e) {
			System.out.println("Error al consultar todos los productos");
			e.printStackTrace();
		} finally {
			cerrarConexion();
		}
			
		return lista;
	}

	@Override
	public boolean insertarNuevo(Producto nuevo) {
		boolean insertado = false;
		try {
			abrirConexion();
			PreparedStatement pst = conexion.prepareStatement("insert into productos values(?,?,?)");
			pst.setInt(1, nuevo.getId());
			pst.setString(2, nuevo.getDescripcion());
			pst.setDouble(3, nuevo.getPrecio());
			
			int registros = pst.executeUpdate();
			if (registros == 1) {
				insertado = true;
			}
			
		} catch (SQLException e) {
			System.out.println("Error al insertar el producto " + nuevo);
			e.printStackTrace();
		} finally {
			cerrarConexion();
		}
		
		return insertado;
	}
	
	@Override
	public Producto buscar(int id) {
		// select * from productos where ID = ?
		Producto producto = null;
		try {
			abrirConexion();
			PreparedStatement srch = conexion.prepareStatement("select * from productos where ID = ?");
			srch.setInt(1, id);
			ResultSet rs = srch.executeQuery();
			
			while(rs.next()) {
				producto = new Producto(rs.getInt("ID"), rs.getString("DESCRIPCION"), rs.getDouble("PRECIO"));
			}		
		
		} catch (SQLException e) {
			//pintamos los errores
			System.out.println("Error al consultar un producto");
			e.printStackTrace();
		} finally {
			cerrarConexion();
		}	
		return producto;
	}
	
	
	@Override
	public boolean eliminarProducto(int id) {
		boolean eliminado= false;
		try {
			abrirConexion();
			
			PreparedStatement pstEliminar = conexion.prepareStatement("delete from productos where ID = ?");
			//Posicion 1,2,3
			pstEliminar.setInt(1, id);
			
			int regEliminar = pstEliminar.executeUpdate();
			
			if(regEliminar == 1) {
				eliminado=true;
			}
	
		} catch (SQLException e) {
			System.out.println("Error al eliminar producto");
			e.printStackTrace();
		}finally {
		
			cerrarConexion();
		}
		return eliminado;
	}

	@Override
	public boolean modificarPrecio(int id, double nuevoPrecio) {
	
		boolean modificado= false;
		try {
			abrirConexion();
			//Los campos tb pueden ir en minuscula
			PreparedStatement pstUpdate = conexion.prepareStatement("update productos set PRECIO = ? where ID = ?");
			//Posicion del campo pero de los parametros a los que hacemos referencia en la consulta
			pstUpdate.setDouble(1, nuevoPrecio);;
			pstUpdate.setInt(2, id);
		
			
			int regModificado = pstUpdate.executeUpdate();
			
			if(regModificado == 1) {
				modificado=true;
			}
	
		} catch (SQLException e) {
			System.out.println("Error al modificar producto");
			e.printStackTrace();
		}finally {
		
			cerrarConexion();
		}
		return modificado;
	}
	
	@Override
	public void abrirConexion() {
		try {
			Class.forName("com.mysql.jdbc.Driver");
			conexion = DriverManager.getConnection("jdbc:mysql://127.0.0.1:3306/msl", "root", "");
		} catch (ClassNotFoundException e) {
			System.out.println("Error en el driver");
			e.printStackTrace();
		} catch (SQLException e) {
			System.out.println("Error al abrir la conexion");
			e.printStackTrace();
		}
	}

	@Override
	public void cerrarConexion() {
		try {
			conexion.close();
		} catch (SQLException e) {
			System.out.println("Error al cerrar la conexion");
			e.printStackTrace();
		}
	}

}
