var mapa;

function mostrar_mapa(){

    // Comprobar si mi navegador soporta Geolocalizacion
    if (navigator.geolocation){
        // Obtener la posicion
        navigator.geolocation.getCurrentPosition(mostrarLocalizacion, manejarError);
    } else {
        alert("Tu navegador no soporta Geolocalizacion");
    }

    var opciones = {
        zoom: 12,
        mapTypeId: google.maps.MapTypeId.ROADMAP
    };

    mapa =  new google.maps.Map(document.getElementById("seccion_mapa"),opciones);

}


function mostrarLocalizacion(posicion){
    // Obtener las coordenadas
    //var pos = new google.maps.LatLng(posicion.coords.latitude, posicion.coords.longitude);

    // Coodenadas de MSL
    var pos = new google.maps.LatLng(40.4357449,-3.6691899);

    // Mostrar la ubicacion en el mapa
    var info = new google.maps.InfoWindow({map: mapa, position: pos, content: 'Estoy aqui'});

    // Pedir que nos centre el mapa
    mapa.setCenter(pos);
}

function manejarError(error){
    switch(error.code){
        case error.PERMISSION_DENIED:
            alert("Permiso denegado");
            break;
        case error.POSITION_UNAVAILABLE:
            alert("No se detecta ubicacion");
            break;
        case error.TIMEOUT:
            alert("Tiempo de espera agotado");
            break;
        case error.UNKNOWN_ERROR:
            alert("Error desconocido");
            break;
    }
}


// Alternativa a <body onload="mostrar_mapa()">
google.maps.event.addDomListener(window, 'load', mostrar_mapa);