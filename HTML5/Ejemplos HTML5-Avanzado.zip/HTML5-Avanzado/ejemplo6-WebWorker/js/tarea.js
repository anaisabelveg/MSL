var i=0;

function contador(){

    // Procesar la informacion recibida de la pagina index
    onmessage = function(e){
        i = parseInt(e.data);
    }

    // Esperar a que pase medio segundo entre numero y numero
    setTimeout(() => {   // crear un temporizador que no recibe ningun argumento
        i++;   // incrementar el numero i
        postMessage(i); // el valor de i se lo pasamos al hilo principal
        contador() // volvemos a llamar al contador
    }, 500 );  // 500 milisegundos es medio segundo, el tiempo que espera para enviar el valor del contador
}

contador();