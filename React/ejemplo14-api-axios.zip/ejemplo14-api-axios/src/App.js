import './App.css';
import Pokemons from './components/Pokemons';

function App() {
  return (
    <div className="App">
      <Pokemons />
    </div>
  );
}

export default App;
