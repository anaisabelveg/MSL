import React from 'react';
import axios from 'axios';

class Pokemons extends React.Component{

    constructor(){
        super();
        this.state = {
            lista_pokemons: []
        }
    }

    async componentDidMount(){
        // Lanzamos la peticion de forma asincrona
        const respuesta = await axios.get('https://pokeapi.co/api/v2/pokemon');
        console.log(respuesta.data.results);

        this.setState({
            lista_pokemons: respuesta.data.results
        })
    }

    ponerFilas = () =>
        this.state.lista_pokemons.map((pokemon) => (
            <tr key={pokemon.name}>
                <td>{pokemon.name}</td>
                <td>{pokemon.url}</td>
            </tr>
        ));
    

    render(){
        return(
            <div>
                <h1>Lista de Pokemons</h1>
                <table border="1">
                    <thead>
                        <tr>
                            <th>NOMBRE</th>
                            <th>URL</th>
                        </tr>
                    </thead>
                    <tbody>
                        {this.ponerFilas()}
                    </tbody>
                </table>
            </div>
        );
    }
}

export default Pokemons;