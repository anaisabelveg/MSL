import logo from './logo.svg';
import './App.css';
import Productos from './pages/Productos';


function App() {
  return (
    <div className="App">
      <Productos />
    </div>
  );
}

export default App;
