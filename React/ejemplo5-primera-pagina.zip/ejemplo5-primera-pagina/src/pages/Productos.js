import React from 'react';
import Formulario from '../components/Formulario';
import Navbar from '../components/Navbar';
import Producto from '../components/Producto';

class Productos extends React.Component{

    // Crear el estado
    state = {
        form: {
            nombre: 'a',
            descripcion:'b',
            precio:'c',
            fabricante:'d',
            imagen:'e'
        }
    }

    modificarEstado = e => {
        this.setState({
            form:{
                // Conservar los datos ya existentes en el estado
                ...this.state.form,
                [e.target.name]: e.target.value
            }
        })
    }


    render(){
        return(
            <div className="container">
                <Navbar />
                <div className="row">
                    <div className="col-md-6">
                        <Producto 
                            nombre={this.state.form.nombre}
                            descripcion={this.state.form.descripcion}
                            precio={this.state.form.precio}
                            fabricante={this.state.form.fabricante}
                            imagen={this.state.form.imagen} />
                    </div>
                    <div className="col-md-6">
                        <Formulario 
                            formValues={this.state.form}
                            onChange={this.modificarEstado}/>
                    </div>
                </div>
            </div>
        );
    }

}

export default Productos;