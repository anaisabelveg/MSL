import React from 'react';

class Navbar extends React.Component{
    render(){
        return(
            <nav className="navbar navbar-dark bg-dark">
                <a className="text-light">Inicio</a>
                <a className="text-light">Catalogo</a>
                <a className="text-light">Contacto</a>
            </nav>
        );
    }
}

export default Navbar;