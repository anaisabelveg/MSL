import './App.css';
import BarraProgreso from './components/BarraProgreso';
import BarraProgresoDinamica from './components/BarraProgresoDinamica';
import Botones from './components/Botones';
import MiSwitch from './components/MiSwitch';

function App() {
  return (
    <div className="App">
      <Botones />
      <MiSwitch />
      <BarraProgreso />
      <BarraProgresoDinamica />
    </div>
  );
}

export default App;
