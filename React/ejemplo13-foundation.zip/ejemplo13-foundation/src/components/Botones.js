import React from 'react';
import {Button} from 'react-foundation-components/lib/button';
import {ButtonGroup} from 'react-foundation-components/lib/button-group';

class Botones extends React.Component{

    render(){
        return(
            <div>
                <Button>Pulsame</Button>

                {/* Colores*/}
                <div>
                    <Button color="primary"> Color primary </Button>
                    <Button color="secondary"> Color secondary </Button>
                    <Button color="alert"> Color alert </Button>
                    <Button color="warning"> Color warning </Button>
                    <Button color="success"> Color success </Button>
                </div>

                {/* Colores*/}
                <div>
                    <Button size="tiny" color="primary"> Color primary </Button>
                    <Button color="secondary"> Color secondary </Button>
                    <Button size="small" color="alert"> Color alert </Button>
                    <Button size="large" color="warning"> Color warning </Button>
                    <Button expanded color="success"> Color success </Button>
                </div>

                <div>
                    <ButtonGroup>
                        <Button color="primary"> Color primary </Button>
                        <Button color="secondary"> Color secondary </Button>
                        <Button color="alert"> Color alert </Button>
                        <Button color="warning"> Color warning </Button>
                        <Button color="success"> Color success </Button>
                    </ButtonGroup>
                </div>

            </div>
        );
    }

}
export default Botones;