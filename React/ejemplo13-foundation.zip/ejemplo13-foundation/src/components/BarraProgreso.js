import React from 'react';
import {ProgressBar} from 'react-foundation-components/lib/progress-bar';

class BarraProgreso extends React.Component{

    render(){
        return(
            <div>
                <ProgressBar />
                <ProgressBar  value={49}/>
                <ProgressBar min={0} max={100}  value={75}/>
                <ProgressBar color="alert" value={49}/>
                <ProgressBar labelFormatter={porcentaje} value={49}/>
                <ProgressBar labelFormatter={etiqueta} value={49} min={0} max={100}/>
            </div>
        );
    }
}

function etiqueta(percent, value, min, max){
    return `percent= ${percent}, value=${value}, min=${min}, max=${max}`;
}

function porcentaje(percent){
    const rounded = Math.round(percent * 100);
    return `${rounded}`;
}

export default BarraProgreso;