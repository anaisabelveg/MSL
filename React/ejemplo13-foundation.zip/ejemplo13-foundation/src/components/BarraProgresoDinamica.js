import React from 'react';
import {ProgressBar} from 'react-foundation-components/lib/progress-bar';

class BarraProgresoDinamica extends React.Component{

    temporizador;

    constructor(){
        super();
        this.state = {
            valor: 0
        }
    }
    
    render(){
        return(
            <div>
                <ProgressBar min={0} max={1000}  value={this.incrementar()}/>
            </div>
        );
    }

    incrementar = () => {
        var i = this.state.valor;
        i++;

        if (this.temporizador){
            clearTimeout(this.temporizador);
        }

        this.temporizador = setTimeout(() => {
            if (i<=1000){
                this.setState({valor: i});
            }
        }, 10);

        return parseInt(i);
    }
}

export default BarraProgresoDinamica;