import React from 'react';
import {Switch, SwitchCheckedLabel, SwitchUncheckedLabel} 
    from 'react-foundation-components/lib/switch';
import {Label} from 'react-foundation-components/lib/label';

class MiSwitch extends React.Component{

    render(){
        return(
            <div>
                <Switch />
                <Switch defaultChecked />

                <div>
                    <Switch size="tiny" />
                    <Switch />
                    <Switch size="small" />
                    <Switch size="large" />
                </div>

                <div>
                    <Label>Estas de acuerdo??</Label>
                    <Switch>
                        <SwitchCheckedLabel>Si</SwitchCheckedLabel>
                        <SwitchUncheckedLabel>No</SwitchUncheckedLabel>
                    </Switch>
                </div>
            </div>
        );
    }

}
export default MiSwitch;