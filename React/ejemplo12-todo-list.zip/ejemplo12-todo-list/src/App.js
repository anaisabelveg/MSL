import React from 'react';
import './App.css';
import TodoForm from './components/TodoForm';
import TodoList from './components/TodoList';

class App extends React.Component {

  constructor(){
    super();

    this.state = {
      arrayDatos:['tarea 1', 'tarea 2', 'tarea 3']
    }
  }

  handleSubmitApp = e => {
    let valor = this.refs.formulario.getValue();
    this.setState(
      {arrayDatos: this.state.arrayDatos.concat(valor)}
    );
  }

  render(){
    return (
      <div className="container">
        <div className="row">
          <div className="col-md-6">
            <TodoForm ref="formulario" onSubmit={this.handleSubmitApp} />
          </div>
          <div className="col-md-6">
            <TodoList coleccion={this.state.arrayDatos} />
          </div>
        </div>
      </div>
    );
  }
}

export default App;
