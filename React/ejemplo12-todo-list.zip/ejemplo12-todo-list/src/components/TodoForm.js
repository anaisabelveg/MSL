import React from 'react';

class TodoForm extends React.Component{

    constructor(){
        super();
        this.state = {
            todoText:''
        }
    }

    handleSubmit = e => {
        // Cancelar el submit
        e.preventDefault();
        // Pasamos el evento a la funcion handleSubmit del componente App
        this.props.onSubmit(e);
    }

    handleChange = e => {
        this.setState({
            todoText: e.target.value
        })
    }

    getValue(){
        return this.state.todoText;
    }
    
    render(){
        return(
            <div>
                <form onSubmit={this.handleSubmit}>
                    <label>Tarea:</label>
                    <input type="text" onChange={this.handleChange} />
                    <input type="submit" value="Agregar" />
                </form>
            </div>
        );
    }

}

export default TodoForm;