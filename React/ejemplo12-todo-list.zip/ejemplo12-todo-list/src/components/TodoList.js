import React from 'react';

class TodoList extends React.Component{

    render(){
        let datos = this.props.coleccion.map((tarea, index) => {
            return(
                <li key={index}>{tarea}</li>
            );
        });
        return(
            
            <ol>
                {datos}
            </ol>
        );
    }
}

export default TodoList;