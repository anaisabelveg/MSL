import './App.css';
import Input from './components/Input';

function App() {
  return (
    <div className="App">
      <Input id={1} type='text' /> <br/>
      <Input id={2} type='password' /> <br/>
      <Input id={3} type='number' /> <br/>
      <Input id={4} type='color' /> <br/>
      <Input id={5} type='date' /> <br/>
      <Input id={6} type='email' /> <br/>
      <Input id={7} type='file' /> <br/>
      <Input id={8} type='button' /> <br/>
    </div>
  );
}

export default App;
