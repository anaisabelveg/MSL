import React from 'react';
import PropTypes from 'prop-types';

class Input extends React.Component{
    render(){
        return(
            <div>
                <p>{"ID: " + this.props.id}</p>
                <input type={this.props.type} />
            </div>
        );
    }
}

Input.propTypes = {
    id: PropTypes.number.isRequired,
    type: PropTypes.string.isRequired
}

export default Input;