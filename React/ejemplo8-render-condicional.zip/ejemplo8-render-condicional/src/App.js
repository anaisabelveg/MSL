import './App.css';

function App() {
  return (
    <div className="App">
      <Mostrar logado={true} />
    </div>
  );
}

// Componente
function UsuarioRegistrado(props){
  return(
    <div>
      <h1>Bienvenido a nuestra aplicacion</h1>
    </div>
  );
}

// Componente
function UsuarioNoRegistrado(props){
  return(
    <div>
      <h1>Por favor, inicie sesion</h1>
    </div>
  );
}

// Version 1 if-else
/*
function Mostrar(props){
    if (props.logado){
      return <UsuarioRegistrado />
    } else {
      return <UsuarioNoRegistrado />
    }
}*/

// Version 2 condicion?true:false
/*
function Mostrar(props){
  return props.logado ? <UsuarioRegistrado /> : <UsuarioNoRegistrado />
}*/

// Version 3 JSX
function Mostrar(props){
  return(
    <div>
      {!props.logado && <UsuarioNoRegistrado />}
      {props.logado && <UsuarioRegistrado />}
    </div>
  );
}


export default App;
