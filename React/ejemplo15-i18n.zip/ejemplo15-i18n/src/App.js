import React from 'react';
import i18n from './i18n';
import { withNamespaces } from 'react-i18next';

import aleman from './images/banderas/germany.png';
import frances from './images/banderas/france.png';
import ingles from './images/banderas/england.png';
import spain from './images/banderas/spain.png';

function App ({ t }) {
  const changeLanguage = (lng) => {
    i18n.changeLanguage(lng);
  }

  return (
    <div>
      <img src={aleman} onClick={() => changeLanguage('de')} />
      <img src={ingles} onClick={() => changeLanguage('en')} />
      <img src={spain} onClick={() => changeLanguage('es')} />
      <h1>{t('Welcome to React')}</h1>
    </div>
  )
}

export default withNamespaces()(App);
