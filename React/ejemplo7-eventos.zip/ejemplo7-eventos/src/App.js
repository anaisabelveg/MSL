import './App.css';

function App() {
  return (
    <div className="App">
      <div className="fondo" 
        onMouseOver={(e) => {alert('Estas dentro')}}
        onMouseOut={(e) => {alert('Estas fuera')}}>
      </div>

      <button onClick={(e)=>{alert('Boton pulsado')}}>
        Pulsame
      </button>

      <p
        onCopy={(e)=>{alert(document.getSelection().toString())}}
        onCut={(e)=>{alert('Texto cortado')}}
        onPaste={(e)=>{alert('Texto pegado')}}>
        Este es un texto para pruebas de eventos
      </p>
    </div>
  );
}

export default App;
