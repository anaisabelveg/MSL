import { Route, BrowserRouter as Router } from 'react-router-dom';
import './App.css';
import Componente1 from './components/Componente1';
import Componente2 from './components/Componente2';
import Componente3 from './components/Componente3';
import Navbar from './components/Navbar';

function App() {
  return (
    <Router>
      <div className="container">
        <Navbar />

        <Route exact path="/c1" component={Componente1} />
        <Route exact path="/c2" component={Componente2} />
        <Route exact path="/c3" component={Componente3} />
      </div>
    </Router>
  );
}

export default App;
