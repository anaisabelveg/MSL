import React from 'react';

class Componente3 extends React.Component{
    render(){
        return(
            <div style={{backgroundColor: 'yellow', height:'500px'}}>
                <h1>Componente 3</h1>
            </div>
        );
    }
}

export default Componente3;