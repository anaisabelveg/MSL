import React from 'react';
import {Link} from 'react-router-dom';

class Navbar extends React.Component{

    render(){
        return(
            <nav className="navbar navbar-dark bg-dark">
                <ul>
                    <li>
                        <Link className="nav-link" to="/c1">Componente 1</Link>
                    </li>
                    <li>
                        <Link className="nav-link" to="/c2">Componente 2</Link>
                    </li>
                    <li>
                        <Link className="nav-link" to="/c3">Componente 3</Link>
                    </li>
                </ul>
            </nav>
        );
    }
}

export default Navbar;