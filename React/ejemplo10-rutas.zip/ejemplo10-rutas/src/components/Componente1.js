import React from 'react';

class Componente1 extends React.Component{
    render(){
        return(
            <div style={{backgroundColor: 'red', height:'500px'}}>
                <h1>Componente 1</h1>
            </div>
        );
    }
}

export default Componente1;