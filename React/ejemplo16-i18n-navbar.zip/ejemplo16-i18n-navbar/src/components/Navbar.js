import React from 'react';
import {Link} from 'react-router-dom';

import { withNamespaces } from 'react-i18next';

function Navbar({ t }) {
 
        return(
            <nav className="navbar navbar-dark bg-dark">
                <ul>
                    <li>
                        <Link className="nav-link" to="/c1">{t('c1')}</Link>
                    </li>
                    <li>
                        <Link className="nav-link" to="/c2">{t('c2')}</Link>
                    </li>
                    <li>
                        <Link className="nav-link" to="/c3">{t('c3')}</Link>
                    </li>
                </ul>
            </nav>
        );
    
}
export default withNamespaces()(Navbar);
