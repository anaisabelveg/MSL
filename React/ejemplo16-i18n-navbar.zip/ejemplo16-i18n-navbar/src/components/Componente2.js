import React from 'react';

class Componente2 extends React.Component{
    render(){
        return(
            <div style={{backgroundColor: 'blue', height:'500px'}}>
                <h1>Componente 2</h1>
            </div>
        );
    }
}

export default Componente2;