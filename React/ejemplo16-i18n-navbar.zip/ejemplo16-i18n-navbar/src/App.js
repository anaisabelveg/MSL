import './App.css';
import { Route, BrowserRouter as Router } from 'react-router-dom';
import Navbar from './components/Navbar';
import Componente1 from './components/Componente1';
import Componente2 from './components/Componente2';
import Componente3 from './components/Componente3';

import aleman from './images/banderas/germany.png';
import frances from './images/banderas/france.png';
import ingles from './images/banderas/england.png';
import spain from './images/banderas/spain.png';

import i18n from './i18n';
import { withNamespaces } from 'react-i18next';


function App({ t }) {
  const changeLanguage = (lng) => {
    i18n.changeLanguage(lng);
  }

  return (
    <Router>
      <div className="container">
      <div>
        <img src={aleman} onClick={() => changeLanguage('de')} />
        <img src={ingles} onClick={() => changeLanguage('en')} />
        <img src={spain} onClick={() => changeLanguage('es')} />
        <h1>{t('Welcome to React')}</h1>
      </div>
        <Navbar />

        <Route exact path="/c1" component={Componente1} />
        <Route exact path="/c2" component={Componente2} />
        <Route exact path="/c3" component={Componente3} />
      </div>
    </Router>
  );
}

export default withNamespaces()(App);
