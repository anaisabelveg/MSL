// Contenido JavaScript
/*
const elemento = document.createElement('h1');
elemento.innerText = 'Bienvenidos al curso de React !!';

const contenedor = document.getElementById('root');
contenedor.appendChild(elemento);
*/

// Contenido JSX
import ReactDOM from 'react-dom';
import React from 'react';

const jsx = <h1> Bienvenidos al curso de React !!</h1>;
const contenedor = document.getElementById('root');

//ReactDOM.render(que_contenido, donde);
ReactDOM.render(jsx, contenedor);

// Otra forma
//React.createElement(elemento, atributos, children);
const enlace = React.createElement('a', 
  {href:'http://google.es',target:'_blank'}, 'Ir a Google');
ReactDOM.render(enlace, contenedor);

const titulo = React.createElement('h1', {}, 'Bienvenidos al curso de React !!');
ReactDOM.render(titulo, contenedor);

// Introducimos variables
const nombre = 'Anabel';
const elementoPersonalizado = React.createElement('h1', {}, `Bienvenid@ ${nombre} al curso de React !!`);
ReactDOM.render(elementoPersonalizado, contenedor);

// JSX es mucho mas limpio
const jsx2 = <h1> Bienvenid@ {nombre} al curso de React !!</h1>;
ReactDOM.render(jsx2, contenedor);

// Resolver expresiones
const jsx3 = <h2>Suma: 3 + 5 = {3+5}</h2>;
ReactDOM.render(jsx3, contenedor);

// Invocar metodos
const resta = (a,b) => {return a-b};
const jsx4 = <h2>Resta: 5 - 3 = {resta(5,3)}</h2>;
ReactDOM.render(jsx4, contenedor);

// Las expresiones que se resuelven como false, null, undefined
// React los ignora y no lo renderiza
const jsx5 = <h1> Bienvenid@ {undefined} al curso de React !!</h1>;
ReactDOM.render(jsx5, contenedor);

// Renderizar mas de un elemento
const elementoMultiple = React.createElement('div', 
  {},
  React.createElement('h1', {}, 'Bienvenidos al curso de React !!'),
  React.createElement('a', {href:'http://google.es',target:'_blank'}, 'Ir a Google')
);
ReactDOM.render(elementoMultiple, contenedor);

// Con JSX todo es mucho mas simple
const jsx6 = (
  <div>
    <h1>Bienvenid@ {nombre} al curso de React !!</h1>
    <a href='http://google.es' target='_blank'>Ir a Google</a>
  </div>
);
ReactDOM.render(jsx6, contenedor);

ReactDOM.render(
  <div>
    <h1>Bienvenid@ {nombre} al curso de React !!</h1>
    <a href='http://google.es' target='_blank'>Ir a Google</a>
  </div>,
  contenedor
);
