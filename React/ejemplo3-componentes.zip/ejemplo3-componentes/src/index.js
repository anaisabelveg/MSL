import React from 'react';
import ReactDOM from 'react-dom';
import Producto from './components/Producto';
import './index.css';
import logo from './images/logo.jpeg';

// Agregamos bootstrap a nuestra app
import 'bootstrap/dist/css/bootstrap.css';

const atributos = {nombre:'Pantalla',
  descripcion: '17 pulgadas extra plana .....', precio: '200€',
  fabricante: 'LG', imagen:'https://assets.mmsrg.com/isr/166325/c1/-/ASSET_MMS_83124575/fee_786_587_png'};

//ReactDOM.render(que,donde);
ReactDOM.render(
  <div>
      <div>
        <img src={logo} alt="MSL" />
      </div>
      <div>
        <Producto nombre='Impresora Laser' 
          descripcion='Impresora con cartucho de color' precio='89€' 
          fabricante='HP' imagen='https://ssl-product-images.www8-hp.com/digmedialib/prodimg/lowres/c05531781.png'/>
        <Producto  {...atributos}/>
      </div>
  </div>,
  document.getElementById('root')
);

