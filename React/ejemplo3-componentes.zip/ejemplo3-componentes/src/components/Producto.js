import React from 'react';
import './styles/Producto.css'

class Producto extends React.Component{

    // Lo minimo que necesita tener un componente es el metodo render()
    render(){
        return(
            <div className='panel'>
                <div>
                    <h1>Detalle del producto</h1>
                    <h2>Nombre: {this.props.nombre}</h2>
                    <h2>Descripcion: {this.props.descripcion}</h2>
                    <h2>Precio: {this.props.precio}</h2>
                    <h2>Fabricante: {this.props.fabricante}</h2>
                </div>
                <div>
                    <img src={this.props.imagen} alt={this.props.nombre} className='imagen'/>
                </div>
            </div>
        );
    }

}

export default Producto;