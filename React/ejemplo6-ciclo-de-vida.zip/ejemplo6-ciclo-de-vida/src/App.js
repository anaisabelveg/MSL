import logo from './logo.svg';
import './App.css';
import Alumnos from './components/Alumnos';

function App() {
  return (
    <div>
      <Alumnos />
    </div>
  );
}

export default App;
