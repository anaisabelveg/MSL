import React from 'react';

class AlumnosList extends React.Component{
    render(){
        return(
            <ul>
                {this.props.lista.map((alumno,index) => {
                    return(
                        <li key={index}>
                            {index +1}.- Nombre: {alumno.nombre}, Nota: {alumno.nota}
                        </li>
                    )
                })}

            </ul>
        )
    }
}

export default AlumnosList;