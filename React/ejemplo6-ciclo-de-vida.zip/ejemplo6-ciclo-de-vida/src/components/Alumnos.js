import React from 'react';
import AlumnosList from './AlumnosList';

class Alumnos extends React.Component{

    constructor(){
        super();
        console.log("Paso 1. Constructor");

        // Podemos inicializar los datos porque es lo primero que se ejecuta
        this.state = {
            data: []
        };
    }

    render(){
        console.log("Paso 2. Render");
        return(
            <div>
                <h1>Lista de alumnos</h1>
                <AlumnosList lista={this.state.data} />
            </div>
        );
    }

    componentDidMount(){
        console.log("Paso 3. El componente ya se ha montado");

        // Imaginamos que los datos se los pedimos a un API
        // Nos aseguramos que el componente ya esta montado
        this.timeoutId = setTimeout(() => {
            this.setState({
                data: [
                    {nombre:'Juan', nota: 7.5},
                    {nombre:'Maria', nota: 8.2},
                    {nombre:'Pedro', nota: 5.6},
                    {nombre:'Laura', nota: 9.3},
                    {nombre:'Luis', nota: 4.3},
                    {nombre:'Miguel', nota: 6.2},
                ]
            })
        }, 5000);
    }

    componentWillUpdate(){
        console.log("Paso 4. El componente se va a modificar");
    }

    componentDidUpdate(){
        console.log("Paso 5. El componente se ha modificado");
    }

    componentWillUnmount(){
        console.log("Paso 6. El componente se va a desmontar");

        // Cancelar tareas
        // Finalizar el timeout porque sino daria un error
        clearTimeout(this.timeoutId);
    }

}

export default Alumnos;