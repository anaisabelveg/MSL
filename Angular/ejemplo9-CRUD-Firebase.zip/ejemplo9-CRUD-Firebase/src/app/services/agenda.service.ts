import { Injectable } from '@angular/core';
import { AngularFirestore } from '@angular/fire/firestore';

@Injectable({
  providedIn: 'root'
})
export class AgendaService {
  // Desde este servicio accedemos a la BBDD y centralizamos
  // todas las operaciones CRUD
  // C (CREATE) -> alta, insertar algo nuevo
  // R (READ) -> consultas, bucar un amigo, consultar todos
  // U (UPDATE) -> modificar, cualquier cambio de un amigo existente
  // D (DELETE) -> borrar, eliminar un amigo de la base de datos

  constructor(private angularFirestore: AngularFirestore) { }

  public todosAmigos(): any{
    return this.angularFirestore.collection('agenda').snapshotChanges();
  }

  public buscarAmigo(id: string): any{
    return this.angularFirestore.collection('agenda').doc(id).snapshotChanges();
  }

  public altaAmigo(nuevo: any): any{
    return this.angularFirestore.collection('agenda').add(nuevo);
  }

  public borrarAmigo(id: string): any{
    return this.angularFirestore.collection('agenda').doc(id).delete();
  }

  public modificarAmigo(id: string, data:any): any{
    return this.angularFirestore.collection('agenda').doc(id).set(data);
  }
}
