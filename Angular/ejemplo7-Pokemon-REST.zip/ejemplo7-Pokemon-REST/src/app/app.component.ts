import { Component } from '@angular/core';
import { PokemonService } from './services/pokemon.service';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  
  pokemons: any = [];
  nombre: string = '';
  pokemon = null;

  constructor(private pokemonService: PokemonService){
    //this.pokemons = this.pokemonService.getAll();

    this.pokemonService.getAll().subscribe((datos) => {
      //console.log(datos);
      this.pokemons = datos['results'];
    });
  }

  buscar(){
    this.pokemonService.buscar(this.nombre).subscribe((item) => {
      //console.log(item);
      this.pokemon = item;
    });
  }
}
