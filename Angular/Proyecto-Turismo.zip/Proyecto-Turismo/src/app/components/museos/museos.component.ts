import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-museos',
  templateUrl: './museos.component.html',
  styleUrls: ['./museos.component.css']
})
export class MuseosComponent implements OnInit {

  museos: any = [
    {id:1, nombre: 'Museo del Prado'},
    {id:2, nombre: 'Reina Sofia'},
    {id:3, nombre: 'Biblioteca nacional'},
    {id:4, nombre: 'Thyssen'},
    {id:5, nombre: 'Real academia de bellas artes de San Fernando'},
    {id:6, nombre: 'Museo Arqueologico'},
    {id:7, nombre: 'Museo Ciencias Naturales'},
    {id:8, nombre: 'Museo del Traje'},
    {id:9, nombre: 'Museo de Ciencia y Tegnologia'},
    {id:10, nombre: 'Museo de Lope de Vega'},
    {id:11, nombre: 'Museo de cera'},
    {id:12, nombre: 'Museo de dibujo e ilustracción'},
    {id:13, nombre: 'Museo de la imprenta'},
    {id:14, nombre: 'Museo naval'},
    {id:15, nombre: 'Museo Sorolla'},
    {id:16, nombre: 'Museo de la ilusion'}
  ];

  constructor() { }

  ngOnInit(): void {
  }

}
