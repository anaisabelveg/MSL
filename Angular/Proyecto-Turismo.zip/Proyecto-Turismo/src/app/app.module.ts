import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppComponent } from './app.component';
import { NavbarComponent } from './components/navbar/navbar.component';
import { MuseosComponent } from './components/museos/museos.component';
import { RutasComponent } from './components/rutas/rutas.component';
import { RouterModule, Routes } from '@angular/router';
import { MuseoDetalleComponent } from './components/museo-detalle/museo-detalle.component';
import { UbicacionMuseoComponent } from './components/ubicacion-museo/ubicacion-museo.component';
import { AgmCoreModule } from '@agm/core';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';

const misRutas: Routes = [
  {path:'museos', component: MuseosComponent},
  {path:'rutas', component: RutasComponent},
  {path:'museo_detalle/:codigo', component: MuseoDetalleComponent},
  {path:'ubicacion_museo', component: UbicacionMuseoComponent}
];

@NgModule({
  declarations: [
    AppComponent,
    NavbarComponent,
    MuseosComponent,
    RutasComponent,
    MuseoDetalleComponent,
    UbicacionMuseoComponent
  ],
  imports: [
    BrowserModule,
    RouterModule.forRoot(misRutas),
    AgmCoreModule.forRoot({
      apiKey: ''
    }),
    BrowserAnimationsModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
