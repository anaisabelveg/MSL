import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppComponent } from './app.component';
import { NavbarComponent } from './components/navbar/navbar.component';
import { MuseosComponent } from './components/museos/museos.component';
import { RutasComponent } from './components/rutas/rutas.component';
import { RouterModule, Routes } from '@angular/router';
import { MuseoDetalleComponent } from './components/museo-detalle/museo-detalle.component';
import { UbicacionMuseoComponent } from './components/ubicacion-museo/ubicacion-museo.component';
import { AgmCoreModule } from '@agm/core';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { RutasService } from './services/rutas.service';
import { RutaDetalleComponent } from './components/ruta-detalle/ruta-detalle.component';
import { UbicacionRutaComponent } from './components/ubicacion-ruta/ubicacion-ruta.component';

const misRutas: Routes = [
  {path:'museos', component: MuseosComponent},
  {path:'rutas', component: RutasComponent},
  {path:'museo_detalle/:codigo', component: MuseoDetalleComponent},
  {path:'ubicacion_museo', component: UbicacionMuseoComponent},
  {path:'ruta_detalle/:codigo', component: RutaDetalleComponent},
  {path:'ubicacion_ruta/:codigo', component: UbicacionRutaComponent}
];

@NgModule({
  declarations: [
    AppComponent,
    NavbarComponent,
    MuseosComponent,
    RutasComponent,
    MuseoDetalleComponent,
    UbicacionMuseoComponent,
    RutaDetalleComponent,
    UbicacionRutaComponent
  ],
  imports: [
    BrowserModule,
    RouterModule.forRoot(misRutas),
    AgmCoreModule.forRoot({
      apiKey: ''
    }),
    BrowserAnimationsModule
  ],
  providers: [RutasService],
  bootstrap: [AppComponent]
})
export class AppModule { }
