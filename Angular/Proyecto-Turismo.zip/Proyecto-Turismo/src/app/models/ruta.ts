export interface Ruta {
    id: number,
    nombre: string,
    duracion: number,
    dificultad: string,
    ubicacion: string,
    coordenadas: number[],
    detalle: string,
    imagen: string
}
