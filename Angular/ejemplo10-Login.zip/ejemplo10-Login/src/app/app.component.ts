import { Component } from '@angular/core';
import { LoginService } from './services/login.service';
import { first, tap } from 'rxjs/operators';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  email: string = '';
  password: string = '';
  confirmPassword: string = '';
  registro: boolean = false; //true->registro, false->login
  logado: boolean = false;

  constructor(private loginService: LoginService) { }

  login() {
    this.loginService.login(this.email, this.password).then((data) => {
      alert("Usuario autenticado");

    }, (error) => {
      console.log(error);
      alert("Usuario no valido");
    });

    this.loginService.comprobar().pipe(first()).pipe(
      tap(user => {
        if (user) {
          this.logado = true;
        } else {
          this.logado = false;
        }
      })
    ).subscribe();
  }

  registrar() {
    if (this.password == this.confirmPassword) {
      this.loginService.registro(this.email, this.password).then((data) => {
        alert("Usuario registrado");
      }, (error) => {
        console.log(error);
        alert("Error de registro");
      });
    } else {
      alert("El password y la confirmacion no coinciden");
    }
  }

  logOut() { 
    this.loginService.logOut(); 
    window.alert('¡¡Hasta pronto!!'); 
    this.logado = false; 
  }
}
