import { Component } from '@angular/core';
import { LoginService } from './services/login.service';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  email: string ='';
  password: string ='';
  confirmPassword: string ='';
  registro:boolean = false; //true->registro, false->login

  constructor(private loginService: LoginService){}

  login(){
    this.loginService.login(this.email,this.password).then((data) => {
      alert("Usuario autenticado");
    }, (error) => {
      console.log(error);
      alert("Usuario no valido");
    });
  }

  registrar(){
    if (this.password == this.confirmPassword){
      this.loginService.registro(this.email,this.password).then((data) => {
        alert("Usuario registrado");
      }, (error) => {
        console.log(error);
        alert("Error de registro");
      });
    } else {
      alert("El password y la confirmacion no coinciden");
    }
  }
}
