import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppComponent } from './app.component';
import { NavbarComponent } from './components/navbar/navbar.component';
import { MuseosComponent } from './components/museos/museos.component';
import { RutasComponent } from './components/rutas/rutas.component';
import { RouterModule, Routes } from '@angular/router';

const misRutas: Routes = [
  {path:'museos', component: MuseosComponent},
  {path:'rutas', component: RutasComponent},
  {path:'', component: AppComponent}
];

@NgModule({
  declarations: [
    AppComponent,
    NavbarComponent,
    MuseosComponent,
    RutasComponent
  ],
  imports: [
    BrowserModule,
    RouterModule.forRoot(misRutas)
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
