import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-museos',
  templateUrl: './museos.component.html',
  styleUrls: ['./museos.component.css']
})
export class MuseosComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
