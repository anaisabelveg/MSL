import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-texto',
  templateUrl: './texto.component.html',
  styleUrls: ['./texto.component.css']
})
export class TextoComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
    // que queremos hacer al iniciar este componente
  }

}
