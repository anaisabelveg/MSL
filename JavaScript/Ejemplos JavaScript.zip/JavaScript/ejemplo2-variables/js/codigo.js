// Crear una variable que se llama nombre y guardamos ahi "Anabel"
// var -> palabra clave para declarar variables
// nombre -> nombre que yo le doy a esa variable
// = -> operador de asignacion
// "Anabel" -> valor de la variable
var nombre = "Anabel";

// Muestra el valor almacenado dentro de la variable nombre
// + -> operador de concatenacion
alert("Me llamo: " + nombre);

// + -> operador suma
alert(3 + 5);