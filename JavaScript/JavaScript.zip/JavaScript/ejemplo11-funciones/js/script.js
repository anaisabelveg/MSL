function funcionesMath(){
    document.getElementById("resultado").innerHTML =
     "<label style='color: red'>Logaritmo:</label> " + Math.log(1000) + "<br/>" +
     "Exponencial: " + Math.exp(8) + "<br/>" +
     "Raiz cuadrada: " + Math.sqrt(9) + "<br/>" +
     "Potencia de 2^8: " + Math.pow(2,8) + "<br/>" +
     "Valor absoluto: " + Math.abs(-668755) + "<br/>" +
     "Redondeo a la baja 6.34566: " + Math.floor(6.34566) + "<br/>" +
     "Redondeo al alza 6.34566: " + Math.ceil(6.34566) + "<br/>" +
     "Redondeo medio 6.34566: " + Math.round(6.34566) + "<br/>" +
     "Random semilla: " + Math.random() + "<br/>" +
     "Random del 1 al 10: " + Math.random()*10 + "<br/>" +
     "Coseno de 180 grados: " + Math.cos(Math.PI) + "<br/>" +
     "Valor maximo: " + Math.max(1,3,6,9) + "<br/>" +
     "Valor minimo: " + Math.min(1,3,6,9) + "<br/>";
}

function funcionesString(){
    var texto = "Bienvenido al curso de JavaScript";

    document.getElementById("resultado").innerHTML =

    // Poner el texto en minusculas
    "Minusculas: " + texto.toLowerCase() + "<br/>" +
    // Poner el texto en mayusculas
    "Mayusculas: " + texto.toUpperCase() + "<br/>" +
    // Mostrar "Bienvenido"
    "Bienvenido: " + texto.slice(0,texto.indexOf(" ")) + "<br/>" +
    // Mostrar "curso"
    "Curso: " + texto.slice(texto.indexOf("c"),texto.indexOf(" ", texto.indexOf("c"))) + "<br/>" +
    // Mostrar "JavaScript"
    "JavaScript: " + texto.slice(texto.lastIndexOf("J")) + "<br/>" +
    // Mostrar "curso de JavaScript" en mayusculas
    "curso de JavaScript: " + (texto.slice(texto.indexOf("c"))).toUpperCase() + "<br/>" +
    // Ver si existe el caracter @
    "Existe @: " + texto.indexOf("@") + "<br/>" +
    // Longitud de la cadena 
    "Longitud: " + texto.length + "<br/>" +
    // Mostrar el caracter unicode 960
    "Caracter unicode: " + String.fromCharCode(960) + "<br/>" +
    // Decir el valor unicode de la letra J
    "Valor unicode: " + texto.charCodeAt(texto.indexOf("J")) + "<br/>" ;
}

function funcionesDate(){
    var fecha = new Date();

    document.getElementById("resultado").innerHTML =
    // Mostrar la fecha
    "Fecha: " + fecha + "<br/>" +
    "Fecha: " + fecha.toLocaleDateString() + "<br/>" +
    // Mostrar la hora
    "Hora: " + fecha.toLocaleTimeString() + "<br/>" +
    // Mostrar diferencia horaria
    "Diferencia horaria: " + fecha.getTimezoneOffset() + "<br/>" +
    // Mostrar horas
    "Horas: " + fecha.getHours() + "<br/>" +
    // Mostrar minutos
    "Minutos: " + fecha.getMinutes() + "<br/>" +
    // Mostrar segundos
    "Segundos: " + fecha.getSeconds() + "<br/>" +
    // Mostrar milisegundos
    "Milisegundos: " + fecha.getMilliseconds() + "<br/>" +
    // Mostrar dia del mes
    "Mes: " + fecha.getDate() + "<br/>" +
    // Mostrar dia
    "Dia: " + fecha.getDay() + "<br/>" +
    // Mostrar mes
    "Mes: " + fecha.getMonth() + "<br/>" +
    // Mostrar año con 2 cifras
    "Año con 2 cifras: " + fecha.getYear() + "<br/>" +
    // Mostrar año con 4 cifras
    "Año con 4 cifras: " + fecha.getFullYear() + "<br/>";
}