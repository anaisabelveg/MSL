var estiloBorde = false; // false->No tiene borde; true ->Si tiene borde
var estiloColor = false;
var estiloSombra = false;

function borde(){
    // Si no tiene borde lo pongo, si lo tiene se lo quito
    if ( estiloBorde == false){
        document.getElementById("cuadrado").style.border = "5px solid blue";
        estiloBorde = true; // Ahora si que tiene borde
    } else {
        document.getElementById("cuadrado").style.border = "none";
        estiloBorde = false; // Ya no tiene borde
    }   
}

function color(){
    // estiloColor == false
    if (!estiloColor){
        document.getElementById("cuadrado").style.backgroundColor = "pink";
        estiloColor = true;
    } else {
        document.getElementById("cuadrado").style.backgroundColor = "paleturquoise";
        estiloColor = false;
    }
}

function sombra(){
    if (!estiloSombra){
        document.getElementById("cuadrado").className = "sombra";
    } else {
        document.getElementById("cuadrado").className = null;
    }
    estiloSombra = !estiloSombra;
}
