// Descargar el modulo http de Node
var http = require("http");
var operaciones = require("./operaciones");
var url = require("url");

// Crear un servidor que escuche en el puerto 7777
http
  .createServer(function (request, response) {
    // Recuperamos el path de la url
    var pathname = url.parse(request.url, true).pathname;

    // Recuperamos los parametros de la url
    var num1 = url.parse(request.url, true).query.numero1;
    var num2 = url.parse(request.url, true).query.numero2;

    // Mostrar que se ha recibido la peticion
    console.log("Peticion recibida");

    // Devolver una respuesta
    // Crear una cabecera
    response.writeHead(200, { "Content-Type": "text/html" });

    switch (pathname) {
      case "/suma":
        response.write(
          JSON.stringify({ Resultado: operaciones.suma(num1, num2) })
        );
        break;
      case "/resta":
        response.write(
          JSON.stringify({ Resultado: operaciones.resta(num1, num2) })
        );
        break;

      case "/multiplicacion":
        response.write(
          JSON.stringify({ Resultado: operaciones.multiplicacion(num1, num2) })
        );
        break;

      case "/division":
        response.write(
          JSON.stringify({ Resultado: operaciones.division(num1, num2) })
        );
        break;

      default:
        response.write("Operacion desconocida");
    }
    
    // Enviar la respuesta
    response.end();
  })
  .listen(7777);
