// Descargar el modulo http de Node
var http = require("http");

// Crear un servidor que escuche en el puerto 7777
http.createServer(function(request,response){

    // Mostrar que se ha recibido la peticion
    console.log("Peticion recibida");

    // Devolver una respuesta
    // Crear una cabecera
    response.writeHead(200, {"Content-Type":"text/html"});

    // Escribir el cuerpo de la respueta
    response.write("Bienvenido al curso de NodeJS");

    // Enviar la respuesta
    response.end();


}).listen(7777);