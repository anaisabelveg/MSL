var express = require('express');
var router = express.Router();
var data = require('../controllers/Data');

/* GET home page. */
router.get('/', function(req, res, next) {
  res.render('index', { title: 'Mis compañeros', nombres: data.getNombres() });
});

router.get('/saludo', function(req, res, next) {
  res.render('saludo', { texto: 'Fuera colacola y viva los gintonics' });
});

module.exports = router;
