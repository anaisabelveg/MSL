var nombres = ["Juan","Maria","Pedro","Luis","Ana","Jorge"];

function getNombres(){
    return nombres;
}

module.exports = {
    getNombres: getNombres
}