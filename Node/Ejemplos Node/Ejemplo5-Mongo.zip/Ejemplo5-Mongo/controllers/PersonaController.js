var personas = require('express').Router(),
    Persona = require('../models/Persona.js');

// Mostrar todas las personas
// localhost:3000/personas
personas.get('/', function(req,res){
    
    Persona.find(function(err, list){
        if (req.accepts('json')){
            if (err){
                return res.json(500, {message: 'Error al consultar todas las personas', error: err});
            }
            return res.json(list)
        } else {
            if (err){
                return res.send('500:Error al consultar todas las personas', 500);
            }
            return res.render('personas/index', {personas: personas});
        }
    });
});  

// Buscar una persona por su id
// localhost:3000/personas/60d4561cff1b62071520fb82
personas.get('/:id', function(req,res){
    var id = req.params.id;
    Persona.findOne({_id:id},function(err, persona){
        if (req.accepts('json')){
            if (err){
                return res.json(500, {message: 'Error buscando persona', error: err});
            }
            if (!persona){
                return res.json(404, {message: 'No se encontro persona', error: err});
            }
            return res.json(persona)
        } else {
            if (err){
                return res.send('500:Error al buscar persona', 500);
            }
            if (!persona){
                return res.send('404:No se encontro persona', 404);
            }
            return res.render('personas/index', {persona: persona});
        }
    });
});  

// Borrar una persona por su id
// localhost:3000/personas/60d4561cff1b62071520fb82
personas.delete('/:id', function(req,res){
    var id = req.params.id;
    
    Persona.findOne({_id:id},function(err, persona){
        if (req.accepts('json')){
            if (err){
                return res.json(500, {message: 'Error buscando persona', error: err});
            }
            if (!persona){
                return res.json(404, {message: 'No se encontro persona', error: err});
            }
            //Eliminamos la persona
            persona.remove(function(err,persona){
                if (req.accepts('json')){
                    if (err){
                        return res.json(500, {message: 'Error borrando persona', error: err});
                    }
                }else{
                    return res.send('No acepta JSON');
                }
            });
            return res.json({message: 'Eliminado'});
        } else {
            return res.send('No acepta JSON');
        }
    });
}); 

// Modificar una persona por su id
// localhost:3000/personas/60d4561cff1b62071520fb82
personas.put('/:id', async (req, res) => {    
    const contactChange = await Persona.findByIdAndUpdate(req.params.id, req.body);    
    res.json({status: "Tu contacto ha sido modificado"});});


// Alta
personas.post('/', function(req,res){
    var persona = new Persona(req.body);
    /*var persona = new Persona({
        'nombre': req.body['nombre'],
        'apellido': req.body['apellido'],
        'edad': req.body['edad']
    });*/

    persona.save(function(err, persona){
        if (req.accepts('json')){
            if (err){
                return res.json(500, {message: 'Error al guardar persona', error: err});
            }
            return res.json({message:'Insertado', _id:persona._id})
        } else {
            if (err){
                return res.send('500:Error al guardar persona', 500);
            }
            return res.render('personas/index', {persona: persona});
        }
    });
});


module.exports = personas;