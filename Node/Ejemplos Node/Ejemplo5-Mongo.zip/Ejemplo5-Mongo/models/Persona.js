var mongoose = require("mongoose");
Schema = mongoose.Schema;
//mongoose.connect("mongodb://localhost/test");
mongoose.connect("mongodb://localhost/local", {
  useUnifiedTopology: true,
  useNewUrlParser: true,
  useFindAndModify: false,
});

// versionKey: false es para que no aparezca ___v: 0 cuando insert una persona
var PersonaSchema = new mongoose.Schema({
  nombre: "String",
  apellido: "String",
  edad: "Number",
},{    
  versionKey: false
});

module.exports = mongoose.model("Persona", PersonaSchema);
