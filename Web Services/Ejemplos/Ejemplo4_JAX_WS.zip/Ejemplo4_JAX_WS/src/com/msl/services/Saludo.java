package com.msl.services;

import javax.jws.WebMethod;
import javax.jws.WebService;

@WebService
public interface Saludo {
	
	@WebMethod
	public String saludar(String nombre);

}
