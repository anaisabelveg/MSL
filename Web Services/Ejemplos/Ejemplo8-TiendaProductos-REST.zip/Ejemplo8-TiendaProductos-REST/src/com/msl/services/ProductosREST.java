package com.msl.services;

import java.util.List;

import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;

import org.json.JSONArray;

import com.msl.modelos.Producto;
import com.msl.negocio.ItfzNegocioProductos;
import com.msl.negocio.NegocioProductos;

@Path("/")
public class ProductosREST {
	
	private ItfzNegocioProductos negocio = new NegocioProductos();
	
	// http://localhost:8080/com.msl.productos/rest/consultar
	@GET
	@Path("consultar")
	@Produces("application/json")
	public String todos() {
		List<Producto> lista = negocio.consultarTodos();
		JSONArray array = new JSONArray(lista);
		return array.toString();
	}

}
