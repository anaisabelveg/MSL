package com.msl.services;

import java.util.List;

import javax.ws.rs.Consumes;
import javax.ws.rs.DELETE;
import javax.ws.rs.FormParam;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

import org.json.JSONArray;
import org.json.JSONObject;

import com.msl.modelos.Producto;
import com.msl.negocio.ItfzNegocioProductos;
import com.msl.negocio.NegocioProductos;

@Path("/")
public class ProductosREST {

	private ItfzNegocioProductos negocio = new NegocioProductos();
	
	// http://localhost:8080/com.msl.productos/rest/modificar
	@PUT
	@Path("modificar")
	@Consumes(MediaType.APPLICATION_FORM_URLENCODED)
	@Produces("application/json")
	public String modificar(@FormParam("id") int id, 
			@FormParam("precio") double precio) {
		boolean modificado = negocio.modificarPrecio(id, precio);
		JSONObject json = new JSONObject();
		json.put("modificado", modificado);
		return json.toString();
	}
	
	// http://localhost:8080/com.msl.productos/rest/alta
		@POST
		@Path("alta")
		@Consumes(MediaType.APPLICATION_FORM_URLENCODED)
		@Produces("application/json")
		public String alta(@FormParam("id") int id, 
				@FormParam("descripcion") String descripcion, 
				@FormParam("precio") double precio) {
			Producto nuevo = new Producto(id, descripcion, precio);
			boolean insertado = negocio.insertarNuevo(nuevo);
			JSONObject json = new JSONObject();
			json.put("insertado", insertado);
			return json.toString();
		}

	// http://localhost:8080/com.msl.productos/rest/eliminar/3
	@DELETE
	@Path("eliminar/{codigo}")
	@Produces("application/json")
	public String eliminar(@PathParam("codigo") int id) {
		boolean eliminado = negocio.eliminarProducto(id);
		JSONObject json = new JSONObject();
		json.put("eliminado", eliminado);
		return json.toString();
	}

	// http://localhost:8080/com.msl.productos/rest/consultar
	@GET
	@Path("consultar")
	@Produces("application/json")
	public String todos() {
		List<Producto> lista = negocio.consultarTodos();
		JSONArray array = new JSONArray(lista);
		return array.toString();
	}

	// http://localhost:8080/com.msl.productos/rest/consultar/3
	@GET
	@Path("consultar/{codigo}")
	@Produces("application/json")
	public String buscar(@PathParam("codigo") int id) {
		Producto producto = negocio.buscar(id);
		JSONObject json = new JSONObject(producto);
		return json.toString();
	}

}
