package com.msl.web;

import java.io.IOException;
import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.annotation.WebFilter;

// El patron /* indica que interceptamos todas las peticiones
// El patron /servlet* interceptamos todo lo que va al servlet
@WebFilter("/*")
public class FiltroMedirTiempo implements Filter {
	
    public FiltroMedirTiempo() {
        // TODO Auto-generated constructor stub
    }

	public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain) throws IOException, ServletException {
		// Interceptamos la peticion
		long tiempoInicio = System.nanoTime();

		// pass the request along the filter chain
		chain.doFilter(request, response);
		
		// Interceptamos la respuesta
		long tiempoFinal = System.nanoTime();
		System.out.println("El tiempo en resolver la peticion ha sido: " + (tiempoFinal-tiempoInicio) + "nanoseg.");
	}

	public void init(FilterConfig fConfig) throws ServletException {
		System.out.println("Se ha creado la instancia del filtro MedirTiempo");
	}
	

	public void destroy() {
		System.out.println("El filtro MedirTiempo se va a destruir");
	}

}
