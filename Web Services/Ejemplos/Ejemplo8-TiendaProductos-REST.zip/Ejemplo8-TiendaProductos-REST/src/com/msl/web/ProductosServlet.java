package com.msl.web;

import java.io.IOException;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletConfig;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebInitParam;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.msl.modelos.Producto;
import com.msl.negocio.Carrito;
import com.msl.negocio.ItfzNegocioProductos;
import com.msl.negocio.NegocioProductos;

@WebServlet(
		urlPatterns = { "/servlet" }, 
		initParams = { 
				@WebInitParam(name = "Oferta", value = "Hoy dto 10% en todos mis productos")
		})
public class ProductosServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	ItfzNegocioProductos negocio = new NegocioProductos();
	
	@Override
	public void init(ServletConfig config) throws ServletException {
		super.init(config);
		
		// Recuperamos el parametro inicial del servlet
		String oferta =  config.getInitParameter("Oferta");
		
		// Recuperar el ambito de la aplicacion, ya que no tenemos acceso al request
		ServletContext ctxApp = config.getServletContext();
		
		// Lo guardamos como atributo de la aplicacion
		ctxApp.setAttribute("msgOferta", oferta);
		
		System.out.println("La instancia del servlet ha sido creada ------");
	}
	
	
	@Override
	public void destroy() {
		super.destroy();
		System.out.println("La instancia del servlet va a ser destruida ------");
	}
	

	public ProductosServlet() {
		super();
		// TODO Auto-generated constructor stub
	}

	private String procesarTodos(HttpServletRequest request, HttpServletResponse response) {
		List<Producto> productos = negocio.consultarTodos();

		// Guardamos la lista de productos como atributo de la peticion
		request.setAttribute("lista", productos);
		
		
		return "/mostrarTodos.jsp";

		// Provocar un error 404
		//return "/mostrarTodossssssss.jsp";
	}
	
	private String procesarBusqueda(HttpServletRequest request, HttpServletResponse response) {
		int id = Integer.parseInt(request.getParameter("codigo"));
		Producto producto = negocio.buscar(id);
		request.setAttribute("encontrado", producto);
		return "/mostrarProducto.jsp";
	}
	
	private String procesarAlta(HttpServletRequest request, HttpServletResponse response) {
		int id = Integer.parseInt(request.getParameter("codigo"));
		String descripcion = request.getParameter("descripcion");
		double precio = Double.parseDouble(request.getParameter("precio"));
		
		boolean insertado = negocio.insertarNuevo(new Producto(id, descripcion, precio));
		if (insertado) {
			request.setAttribute("mensaje", "Producto insertado en la BBDD correctamente");
		} else {
			request.setAttribute("mensaje", "No se pudo insertar el producto en la BBDD");
		}
		
		return "/mostrarMensaje.jsp";
	}

	private String procesarEliminar(HttpServletRequest request, HttpServletResponse response) {
		int id = Integer.parseInt(request.getParameter("codigo"));
		boolean eliminado = negocio.eliminarProducto(id);
		if (eliminado) {
			request.setAttribute("mensaje", "Producto eliminado de la BBDD correctamente");
		} else {
			request.setAttribute("mensaje", "No se pudo eliminar el producto de la BBDD");
		}
		return "/mostrarMensaje.jsp";
	}
	
	private String procesarModificar(HttpServletRequest request, HttpServletResponse response) {
		int id = Integer.parseInt(request.getParameter("codigo"));
		double precio = Double.parseDouble(request.getParameter("precio"));
		boolean modificado = negocio.modificarPrecio(id, precio);
		if (modificado) {
			request.setAttribute("mensaje", "Producto modificado de la BBDD correctamente");
		} else {
			request.setAttribute("mensaje", "No se pudo modificar el producto de la BBDD");
		}
		return "/mostrarMensaje.jsp";
	}
	
	private String procesarCompra(HttpServletRequest request, HttpServletResponse response) {
		// Recuperar las cookies y ver si existe una cookie de usuario
		String nombre = "";
		Cookie[] todasCookies = request.getCookies();
		for (Cookie cookie : todasCookies) {
			if ("usuario".equals(cookie.getName())){
				nombre = cookie.getValue();
			}
		}
		
		// Si existe el nombre entonces puede comprar, sino redirigimos a formularioLogin
		if (nombre.length() == 0) {
			return "/formularioLogin.jsp";
		} else {
		
			// Recuperar el codigo del producto
			int id = Integer.parseInt(request.getParameter("codigo"));
			
			// Recuperar la session del usuario. Si no existe session se crea
			// true -> si no existe la session la crea. Es lo mismo que getSession()
			// false -> si no existe la sesion NO la crea.
			HttpSession miSession = request.getSession(true);
			
			// Agregamos un nuevo carrito a esa session nueva o recuperar el carrito de la session existente
			Carrito carrito = (Carrito) miSession.getAttribute("miCarro");
			if (carrito == null) {
				carrito = new Carrito();
				miSession.setAttribute("miCarro", carrito);
			}
			
			// Guardamos el nombre como atributo de la sesion
			miSession.setAttribute("nombreUsuario", nombre);
			
			// Agregamos el producto al carrito
			carrito.addProducto(id);
			
			// Devolvemos la vista
			return "/mostrarCarrito.jsp";
		}// fin else
	}
	
	private String procesarSacarProducto(HttpServletRequest request, HttpServletResponse response) {
		// Recuperar el codigo del producto
		int id = Integer.parseInt(request.getParameter("codigo"));
		
		// Recuperar la session del usuario que debe de existir
		// true -> si no existe la session la crea. Es lo mismo que getSession()
		// false -> si no existe la sesion NO la crea.
		HttpSession miSession = request.getSession(false);
		
		// Agregamos un nuevo carrito a esa session nueva o recuperar el carrito de la session existente
		Carrito carrito = (Carrito) miSession.getAttribute("miCarro");
		
		// Agregamos el producto al carrito
		carrito.sacarProducto(id);
		
		// Devolvemos la vista
		return "/mostrarCarrito.jsp";
	}
	
	private String procesarLogin(HttpServletRequest request, HttpServletResponse response) {
		// Recuperar el usuario
		String nombre = request.getParameter("user");
		
		// Crear la cookie
		Cookie miCookie = new Cookie("usuario", nombre);
		
		// Establecer permanencia en segundos
		miCookie.setMaxAge(24*60*60); // 1 dia
		
		// Adjuntar la cookie a la respuesta
		response.addCookie(miCookie);
		
		// Devolver la vista
		//return "/index.jsp";
		return "/servlet?op=1";
	}
	
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		
		// Muestre por consola el encoding recibido
		System.out.println(request.getCharacterEncoding());
		
		String vista = "/index.jsp";

		switch (request.getParameter("op")) {
			case "1": // consultar todos
				vista = procesarTodos(request, response);
				break;
	
			case "2": // buscar un producto
				vista = procesarBusqueda(request, response);
				break;
	
			case "3": // alta producto
				vista = procesarAlta(request, response);
				break;
	
			case "4": // eliminar producto
				vista = procesarEliminar(request, response);
				break;
	
			case "5": // modificar producto
				vista = procesarModificar(request, response);
				break;
	
			case "6": // comprar producto
				vista = procesarCompra(request, response);
				break;
	
			case "7": // sacar producto del carrito
				vista = procesarSacarProducto(request, response);
				break;
	
			case "8": // procesar el login
				vista = procesarLogin(request, response);
				break;
	
			default:
				break;
		}

		// Elegir la vista que mostrara el resultado
		RequestDispatcher rd = request.getRequestDispatcher(vista);

		// Redigir hacia esa pagina
		rd.forward(request, response);

	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
