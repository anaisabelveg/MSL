package com.msl.parser;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Text;

public class Principal{

	public static void main(String[] args) throws Exception {
		DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();
		DocumentBuilder db = dbf.newDocumentBuilder();
		Document document = db.parse("empleados.xml");
		
		Element raiz = document.getDocumentElement();
		
		Element newEmp = document.createElement("empleado");
		
		Element newId = document.createElement("id");
		Text IDText = document.createTextNode("00133");
		newId.appendChild(IDText);
		
		Element newNombre = document.createElement("nombre");
		Text nombreText = document.createTextNode("Luis Sanchez");
		newNombre.appendChild(nombreText);
		
		Element newDir = document.createElement("direccion");
		
		Element newCalle = document.createElement("calle");
		Text calleText = document.createTextNode("Castellana");
		newCalle.appendChild(calleText);
		
		Element newCiudad = document.createElement("ciudad");
		Text ciudadText = document.createTextNode("Madrid");
		newCiudad.appendChild(ciudadText);
		
		Element newCP = document.createElement("codigo_postal");
		Text cpText = document.createTextNode("28016");
		newCP.appendChild(cpText);
		
		newDir.appendChild(newCalle);
		newDir.appendChild(newCiudad);
		newDir.appendChild(newCP);
		
		Element newEmail = document.createElement("email");
		Text emailText = document.createTextNode("luis@yahoo.es");
		newEmail.appendChild(emailText);
		
		Element newDpto = document.createElement("dpto");
		Text dptoText = document.createTextNode("Compras");
		newDpto.appendChild(dptoText);
		
		Element newSueldo = document.createElement("sueldo");
		Text sueldoText = document.createTextNode("60000");
		newSueldo.appendChild(sueldoText);
		
		newEmp.appendChild(newId);
		newEmp.appendChild(newNombre);
		newEmp.appendChild(newDir);
		newEmp.appendChild(newEmail);
		newEmp.appendChild(newDpto);
		newEmp.appendChild(newSueldo);
		
		raiz.appendChild(newEmp);
		
		TransformerFactory tf = TransformerFactory.newInstance();
		Transformer transformer = tf.newTransformer();
		
		DOMSource source = new DOMSource(document);
		StreamResult resultado = new StreamResult("empleados.xml");
		
		transformer.transform(source, resultado);
	}

	

}
