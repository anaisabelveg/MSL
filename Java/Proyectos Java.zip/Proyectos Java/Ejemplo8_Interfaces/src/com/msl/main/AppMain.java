package com.msl.main;

import com.msl.models.Animal;
import com.msl.models.AnimalDomestico;
import com.msl.models.Perro;
import com.msl.models.ProductoVenta;

public class AppMain {

	public static void main(String[] args) {
		// crear un objeto perro
		Perro perro = new Perro(true, 3, "Fifi", 230.95, "PE-1234");	
		System.out.println(perro);
		
		
		// Polimorfismo
		// Es la capacidad de VER un objeto de diferentes formas
		
		Object object = new Perro(true, 3, "Fifi", 230.95, "PE-1234");
		// Veo el perro como un Object
		// Solo tengo acceso a los recursos de la clase Object
		object.toString();
		
		// Cambiar la visibilidad de un objeto se hace mediante casting
		Perro perro2 = (Perro) object;
		
		Animal animal  = new Perro(true, 3, "Fifi", 230.95, "PE-1234");
		// Veo el perro como un Animal
		// Solo tengo acceso a los recursos de la clase Object y Animal 
		animal.getEdad();
		
		// Todos los animales NO SON PERROS
		// Perro perro2 = new Animal();
		
		// No puedo crear instancias de interfaces
		//Animal animal2 = new AnimalDomestico();
		
		// Pero si las puedo utilizar como tipo de dato
		AnimalDomestico animalDomestico = new Perro(true, 3, "Fifi", 230.95, "PE-1234");
		animalDomestico.comer();
		ProductoVenta productoVenta = new Perro(true, 3, "Fifi", 230.95, "PE-1234");
		productoVenta.getCodigo();
	}

}
