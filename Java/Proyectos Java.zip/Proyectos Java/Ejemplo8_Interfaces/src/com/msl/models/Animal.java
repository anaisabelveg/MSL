package com.msl.models;

public class Animal {

	private boolean domestico;
	private int edad;

	public Animal() {
		// TODO Auto-generated constructor stub
	}

	public Animal(boolean domestico, int edad) {
		super();
		this.domestico = domestico;
		this.edad = edad;
	}

	public boolean isDomestico() {
		return domestico;
	}

	public void setDomestico(boolean domestico) {
		this.domestico = domestico;
	}

	public int getEdad() {
		return edad;
	}

	public void setEdad(int edad) {
		this.edad = edad;
	}

	@Override
	public String toString() {
		return "Animal [domestico=" + domestico + ", edad=" + edad + "]";
	}

}
