package com.msl.models;

// Una interface es una clase abstracta llevada al extremo.
// Todos los metodos son abstractos
public interface AnimalDomestico {
	
	// Por defecto todos los metodos son public y abstract
	String pasear();
	String comer();
	String vacunar();

}
