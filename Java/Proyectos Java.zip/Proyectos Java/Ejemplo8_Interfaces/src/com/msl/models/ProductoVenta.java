package com.msl.models;

public interface ProductoVenta {
	
	// Se pueden declarar propiedades pero seran estaticas y finales
	
	double getPrecio();
	String getCodigo();

}
