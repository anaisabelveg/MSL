package com.msl.models;

// En Java la herencia es simple. Solo podemos heredar de una clase
// Simular herencia multiple
public class Perro extends Animal implements AnimalDomestico, ProductoVenta {

	private String nombre;
	private double precio;
	private String codigo;

	public Perro() {
		// TODO Auto-generated constructor stub
	}

	public Perro(boolean domestico, int edad, String nombre, double precio, String codigo) {
		super(domestico, edad);
		this.nombre = nombre;
		this.precio = precio;
		this.codigo = codigo;
	}

	public String getNombre() {
		return nombre;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	@Override
	public String toString() {
		return "Perro [nombre=" + nombre + ", precio=" + precio + ", codigo=" + codigo + ", toString()="
				+ super.toString() + "]";
	}

	@Override
	public String pasear() {
		// TODO Auto-generated method stub
		return "Saco a pasear a " + nombre;
	}

	@Override
	public String comer() {
		// TODO Auto-generated method stub
		return "Mi perrito " + nombre + " come pienso";
	}

	@Override
	public String vacunar() {
		// TODO Auto-generated method stub
		return " Hoy toca vacunar a " + nombre;
	}

	@Override
	public double getPrecio() {
		// TODO Auto-generated method stub
		return precio;
	}

	@Override
	public String getCodigo() {
		// TODO Auto-generated method stub
		return codigo;
	}

	public void setCodigo(String codigo) {
		this.codigo = codigo;
	}

	public void setPrecio(double precio) {
		this.precio = precio;
	}

}
