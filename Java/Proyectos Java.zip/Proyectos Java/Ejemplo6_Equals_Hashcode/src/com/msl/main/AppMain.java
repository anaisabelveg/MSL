package com.msl.main;

import com.msl.models.Alumno;

public class AppMain {

	public static void main(String[] args) {
		
		Alumno alumno1 = new Alumno("Juan", 6.4);
		Alumno alumno2 = new Alumno("Juan", 6.4);
		
		int numero1 = 8;
		int numero2 = 8;
		
		// Comparar objetos
		System.out.println("Son iguales los alumnos? " + (alumno1 == alumno2));
		System.out.println("Son iguales los alumnos con equals? " + (alumno1.equals(alumno2)));
		
		// El operador == compara el contenido de las variables
		// En el caso de que sean objetos esta comparando direcciones de memoria
		System.out.println("Son iguales los numeros? " + (numero1 == numero2));

	}

}
