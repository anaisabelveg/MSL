package com.msl.una.dimension;

import java.util.Arrays;

public class AppMain {

	public static void main(String[] args) {
		// Declarar una variable de tipo array
		int numeros[];
		int[] numeros2;
		int [] numeros3;
		
		// Crear el array
		numeros = new int[5];
		numeros2 = new int[] {1,5,3,9,8};
		
		// Llenar de datos el array
		numeros[0] = 5;
		numeros[1] = 2;
		numeros[2] = 7;
		numeros[3] = 3;
		numeros[4] = 4;
		
		// Recorrer un array con for tradicional
		for(int i=0; i<numeros.length; i++) {
			System.out.println(numeros[i]);
		}
		
		// Recorrer un array con for-each
		for (int numero : numeros2) {
			System.out.println(numero);
		}
		
		String nombres[] = {"Pepito","Juanito","Miguelito"};
		for (String nombre : nombres) {
			System.out.println(nombre.toUpperCase() + " , numero de caracteres: " + nombre.length());
		}
		
		// En Java, los arrays no son redimensionables
		// Solucion: Crear un array con mas elementos y volcar los datos
		String nombres2[] = new String[6];
		System.arraycopy(nombres, 0, nombres2, 0, nombres.length);
		
		// Mostrar el contenido de un array
		System.out.println(nombres2.toString());
		System.out.println(Arrays.toString(nombres2));

	}

}
