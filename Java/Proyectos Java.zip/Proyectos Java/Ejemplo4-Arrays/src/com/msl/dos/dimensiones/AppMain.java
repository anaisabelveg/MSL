package com.msl.dos.dimensiones;

import java.util.Arrays;

public class AppMain {

	public static void main(String[] args) {
		// Declarar una variable de tipo array de 2 dimensiones
		int numeros[][];
		int[][] numeros2;
		
		// Declarar una variable de tipo array de 3 dimensiones
		int [][][] numeros3;
		
		// Crear el array
		// Matriz cuadrada (mismo numero de columnas en todas las filas)
		numeros = new int[3][2];
		//numeros2 = new int[] {1,5,3,9,8};
		
		// Llenar de datos el array
		numeros[0][0] = 5;
		numeros[0][1] = 2;
		numeros[1][0] = 7;
		numeros[1][1] = 3;
		numeros[2][0] = 4;
		numeros[2][1] = 6;
		
		// Recorrer un array con for tradicional
		for(int fila=0; fila<numeros.length; fila++) {
			for(int col=0; col<numeros[fila].length; col++) {
				System.out.print(numeros[fila][col] + "\t");
			}
			System.out.println();
		}
		
		
		// Recorrer un array con for-each
		for (int fila[] : numeros) {
			for (int dato : fila) {
				System.out.print(dato + "\t");
			}
			System.out.println();
		}
		
		// Matriz no cuadrada, cada fila tiene diferente numero de columnas
		String nombres[][] = {{"Pepito","Juanito","Miguelito"}, {"Maria","Laura"}, {"Luis"}};
		for (String fila[] : nombres) {
			for (String nombre: fila){
				System.out.println(nombre.toUpperCase() + " , numero de caracteres: " + nombre.length());
			}
		}
		
		/*
		// En Java, los arrays no son redimensionables
		// Solucion: Crear un array con mas elementos y volcar los datos
		String nombres2[] = new String[6];
		System.arraycopy(nombres, 0, nombres2, 0, nombres.length);
		*/
		
		// Mostrar el contenido de un array
		System.out.println(nombres.toString());
		System.out.println(Arrays.deepToString(nombres));
		

	}

}
