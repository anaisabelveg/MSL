package com.msl.lambdas;

public class PruebaLambda {

	public static void main(String[] args) {
		
		ICalculadoraLambda  iSuma = (num1, num2) -> num1 + num2;
		System.out.println("Suma: " + iSuma.operacion(8, 6));
		
		ICalculadoraLambda  iResta = (num1, num2) -> num1 - num2;
		System.out.println("Resta: " + iResta.operacion(8, 6));
		
		ICalculadoraLambda  iMultiplicacion = (num1, num2) -> num1 * num2;
		System.out.println("Multiplicacion: " + iMultiplicacion.operacion(8, 6));
		
		ICalculadoraLambda  iDivision = (num1, num2) -> num1 / num2;
		System.out.println("Division: " + iDivision.operacion(8, 6));
	}

}
