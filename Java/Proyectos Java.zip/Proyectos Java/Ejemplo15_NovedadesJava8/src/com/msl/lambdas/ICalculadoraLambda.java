package com.msl.lambdas;

public interface ICalculadoraLambda {
	
	public int operacion(int num1, int num2);

}
