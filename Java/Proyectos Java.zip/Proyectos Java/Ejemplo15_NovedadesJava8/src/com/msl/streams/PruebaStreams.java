package com.msl.streams;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.function.Predicate;
import java.util.stream.Stream;

public class PruebaStreams {

	public static void main(String[] args) {
		
		List<String> nombres = new ArrayList<>();
		nombres.add("Juan");
		nombres.add("Pedro");
		nombres.add("Maria");
		nombres.add("Pepe");
				
		// Perecido a obtener un iterador para recorrer la coleccion
		Stream<String> stream = nombres.stream();
		
		System.out.println("Cuantos nombres?: " + stream.count());
		
		Optional<String> nombre = nombres.stream()
			.filter(Predicate.isEqual("Juan"))
			.map((String n) -> {return n;})
			.findFirst();

		
		System.out.println(nombre.get());
			
	}

}
