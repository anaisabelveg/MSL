package com.msl.metodos.interfaces;

public interface IPrueba {
	
	public void implementar();
	
	public default void defecto() {
		System.out.println("Mensaje desde el metodo defecto");
	}
	
	public static void estatico() {
		System.out.println("Mensaje desde el metodo estatico");
	}

}
