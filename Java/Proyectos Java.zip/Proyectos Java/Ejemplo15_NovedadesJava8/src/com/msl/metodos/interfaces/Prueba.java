package com.msl.metodos.interfaces;

public class Prueba implements IPrueba {

	@Override
	public void implementar() {
		System.out.println("Metodo implementado");
	}
	
	// El metodo por defecto se puede sobreescribir
	@Override
	public void defecto() {
		// TODO Auto-generated method stub
		IPrueba.super.defecto();
	}
	
	// El metodo estatico no se puede sobreescribir,
	// Los recursos estaticos NO SE HEREDAN
	

}
