package com.msl.metodos.interfaces;

public class PruebaMetodos {

	public static void main(String[] args) {
		
		Prueba prueba = new Prueba();
		prueba.implementar();
		prueba.defecto();
		
		// Aqui no funciona porque el recurso
		// estatico esta declarado en la interface, 
		// no en la clase
		//prueba.estatico();
		
		IPrueba.estatico();

	}

}
