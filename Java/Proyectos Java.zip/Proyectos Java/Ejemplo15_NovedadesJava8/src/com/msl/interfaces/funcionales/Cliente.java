package com.msl.interfaces.funcionales;

public class Cliente {
	
	private String nombre;
	private String nif;
	private double cifraVentas;
	
	public Cliente() {
		// TODO Auto-generated constructor stub
	}

	public Cliente(String nombre, String nif, double cifraVentas) {
		super();
		this.nombre = nombre;
		this.nif = nif;
		this.cifraVentas = cifraVentas;
	}

	public String getNombre() {
		return nombre;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	public String getNif() {
		return nif;
	}

	public void setNif(String nif) {
		this.nif = nif;
	}

	public double getCifraVentas() {
		return cifraVentas;
	}

	public void setCifraVentas(double cifraVentas) {
		this.cifraVentas = cifraVentas;
	}

	@Override
	public String toString() {
		return "Cliente [nombre=" + nombre + ", nif=" + nif + ", cifraVentas=" + cifraVentas + "]";
	}
	
	

}
