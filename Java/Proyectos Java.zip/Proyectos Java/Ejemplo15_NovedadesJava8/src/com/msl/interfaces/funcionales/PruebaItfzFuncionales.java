package com.msl.interfaces.funcionales;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class PruebaItfzFuncionales {

	public static void main(String[] args) {
		
		List<Cliente> lista = new ArrayList<>();
		
		lista.add(new Cliente("Juan", "1111-A", 1500));
		lista.add(new Cliente("Jose", "3333-B", 1200));
		lista.add(new Cliente("Maria", "2222-C", 1800));
		lista.add(new Cliente("Laura", "4444-D", 1100));
		
		System.out.println(lista);
		
		Collections.sort(lista, (c1,c2) -> c1.getNombre().compareTo(c2.getNombre()));
		
		System.out.println("Ordenado por nombre");
		System.out.println("-------------------");
		lista.stream().forEach(cliente -> System.out.println(cliente));
		
		
		Collections.sort(lista, (c1,c2) -> c1.getNif().compareTo(c2.getNif()));
		
		System.out.println("Ordenado por nif");
		System.out.println("-------------------");
		lista.stream().forEach(cliente -> System.out.println(cliente));
		
		Collections.sort(lista, (c1,c2) -> Double.valueOf(c1.getCifraVentas()).compareTo(Double.valueOf(c2.getCifraVentas())));
		
		System.out.println("Ordenado por cifra de ventas");
		System.out.println("-------------------");
		lista.stream().forEach(cliente -> System.out.println(cliente));

	}

}
