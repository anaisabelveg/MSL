package vegas.anabel.main;

import vegas.anabel.models.Circulo;
import vegas.anabel.models.Rectangulo;
import vegas.anabel.models.Triangulo;

public class AppMain {

	public static void main(String[] args) {
		
		Circulo circulo = new Circulo();
		circulo.radio = 6.2;
		System.out.println("Area del circulo: " + circulo.calcularArea());
		
		Rectangulo rectangulo = new Rectangulo();
		rectangulo.base = 7;
		rectangulo.altura = 3;
		System.out.println("Area del rectangulo: " + rectangulo.calcularArea());
		
		Triangulo triangulo = new Triangulo();
		triangulo.base = 10;
		triangulo.altura = 3;
		System.out.println("Area del triangulo: " + triangulo.calcularArea());
		
	}

}
