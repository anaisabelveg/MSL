package vegas.anabel.models;

public class Rectangulo {
	
	public double base;
	public double altura;
	
	public double calcularArea() {
		return base * altura;
	}

}
