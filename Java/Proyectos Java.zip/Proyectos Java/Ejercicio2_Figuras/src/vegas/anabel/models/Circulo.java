package vegas.anabel.models;

public class Circulo {
	
	public double radio;
	
	public double calcularArea() {
		//return Math.PI * radio * radio;
		return Math.PI * Math.pow(radio, 2);
	}

}
