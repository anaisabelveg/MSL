package vegas.anabel.models;

public class Triangulo {
	
	public double base;
	public double altura;
	
	public double calcularArea() {
		return (base * altura) / 2 ;
	}

}
