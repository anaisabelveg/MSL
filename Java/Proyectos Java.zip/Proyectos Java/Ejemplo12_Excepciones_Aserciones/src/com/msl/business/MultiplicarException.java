package com.msl.business;

// RuntimeException se considera UncheckedException
// Significa que al lanzar la excepcion no salta aviso de captura.
public class MultiplicarException extends RuntimeException{
	
	@Override
	public String getMessage() {
		// TODO Auto-generated method stub
		return "El resultado siempre va a ser cero";
	}

}
