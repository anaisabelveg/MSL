package com.msl.business;

public class Operaciones {
	
	public double sumar(double num1, double num2) {
		return num1 + num2;
	}
	
	public double restar(double num1, double num2) {
		return num1 - num2;
	}
	
	public double multiplicar(double num1, double num2) {
		if (num2 == 0) {
			throw new MultiplicarException();
		}
		return num1 * num2;
	}
	
	// throws DivisorException -> devolver la excepcion a quien ha llamado a este metodo
	public double division(double num1, double num2) throws DivisorException {
		// Si el divisor es cero LANZO una excepcion
		if (num2 == 0) {
			 throw new DivisorException();
		}
		return num1 / num2;
	}

}
