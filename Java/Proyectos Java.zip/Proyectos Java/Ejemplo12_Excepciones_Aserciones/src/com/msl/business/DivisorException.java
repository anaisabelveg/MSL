package com.msl.business;

// Creamos nuestra propia excepcion personalizada
public class DivisorException extends Exception{
	
	@Override
	public String getMessage() {
		// TODO Auto-generated method stub
		return "El divisor no puede ser cero";
	}

}
