package com.msl.main;

import java.io.FileNotFoundException;
import java.util.Scanner;

import com.msl.business.DivisorException;
import com.msl.business.Operaciones;

public class AppMain {

	// CUIDADO !!! Estoy devolviendo la excepcion a la maquina virtual
	//public static void main(String[] args) throws DivisorException {
	public static void main(String[] args) {
		// Solicitar al usuario 2 numeros
		
		// Crear un objeto scanner para reconocer el teclado
		Scanner sc = new Scanner(System.in);
		System.out.println("Introduce el primer numero");	
		double n1 = sc.nextDouble();
		
		System.out.println("Introduce el segundo numero");	
		double n2 = sc.nextDouble();
		
		// Crear la instancia de operaciones
		Operaciones operaciones = new Operaciones();
		
		System.out.println(n1 + " + " + n2 + " = " + operaciones.sumar(n1, n2) );
		System.out.println(n1 + " - " + n2 + " = " + operaciones.restar(n1, n2) );
		System.out.println(n1 + " * " + n2 + " = " + operaciones.multiplicar(n1, n2) );
		try {
			System.out.println(n1 + " / " + n2 + " = " + operaciones.division(n1, n2) );
		} catch (DivisorException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		
		int resultado = 0;
		int numero = 0;
		for (String dato : args) {
			try {
				// Aqui colocamos las instrucciones que pueden generar un error
				numero = Integer.parseInt(dato);
				
				// Por defecto, todas las aserciones estan deshabilitadas
				assert (numero >= 0) : "El numero debe ser positivo";
			} catch (NumberFormatException e) {
				// Si se produce una excepcion de tipo NumberFormatException
				// la capturamos, para que ese error no llegue a la maquina virtual
				// y de esa forma el programa continua.
				System.out.println("Cuidado!!! error con un dato");
				numero = 0;
				System.out.println(e.getMessage());
				e.printStackTrace();
		
				// TODO: handle exception
			} catch (NullPointerException e) {
				// TODO: handle exception
			} catch (Exception e) {
				// Aqui se captura cualquier excepcion
				// Claro ejemplo de uso de polimorfismo
			}
			
			resultado += numero;
		}
		System.out.println("Resultado: " + resultado);

	}

}










