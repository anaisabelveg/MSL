package vegas.anabel.main;

import vegas.anabel.models.Alumno;
import vegas.anabel.models.Direccion;
import vegas.anabel.models.Expediente;

public class AppMain {

	public static void main(String[] args) {
		Alumno alumno = new Alumno();
		alumno.nombre = "Pepito";
		alumno.edad = 12;
		alumno.curso = "1 ESO";
		
		alumno.direccion = new Direccion();
		alumno.direccion.calle = "Mayor";
		alumno.direccion.numero = 29;
		alumno.direccion.piso = 5;
		alumno.direccion.letra = 'B';
		alumno.direccion.codigoPostal = 28117;
		alumno.direccion.poblacion = "Madrid";
		alumno.direccion.provincia = "Madrid";
		
		alumno.expediente = new Expediente();
		alumno.expediente.matematicas = 7.8;
		alumno.expediente.lengua = 9.1;
		alumno.expediente.sociales = 5.7;
		alumno.expediente.plastica = 4.2;
		
		System.out.println(alumno);
		
		
		Alumno alumno2 = new Alumno();
		alumno2.nombre = "Maria";
		alumno2.edad = 9;
		alumno2.curso = "3 Primaria";
		
		Direccion dirMaria = new Direccion();
		dirMaria.calle = "Gran Via";
		dirMaria.numero = 27;
		dirMaria.piso = 3;
		dirMaria.letra = 'A';
		dirMaria.codigoPostal = 28115;
		dirMaria.poblacion = "Madrid";
		dirMaria.provincia = "Madrid";
		
		alumno2.direccion = dirMaria;
		
		Expediente expMaria = new Expediente();
		expMaria.matematicas = 6.8;
		expMaria.lengua = 9.3;
		expMaria.sociales = 6.1;
		expMaria.plastica = 5.2;
		
		alumno2.expediente = expMaria;
		
		System.out.println(alumno2);
		
		
	}

}
