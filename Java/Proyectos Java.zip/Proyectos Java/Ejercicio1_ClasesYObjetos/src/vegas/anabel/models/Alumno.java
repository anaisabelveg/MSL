package vegas.anabel.models;

public class Alumno {
	
	public String nombre;
	public int edad;
	public String curso;
	public Direccion direccion = null;
	public Expediente expediente;
	
	
	@Override
	public String toString() {
		return "Alumno [nombre=" + nombre + ", edad=" + edad + ", curso=" + curso + ", direccion=" + direccion
				+ ", expediente=" + expediente + "]";
	}
	
}
