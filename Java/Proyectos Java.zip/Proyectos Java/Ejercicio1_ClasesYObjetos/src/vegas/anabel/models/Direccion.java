package vegas.anabel.models;

public class Direccion {
	public String calle;
	public int numero;
	public int piso;
	public char letra;
	public int codigoPostal;
	public String poblacion;
	public String provincia;
	
	
	@Override
	public String toString() {
		return "calle=" + calle + ", numero=" + numero + ", piso=" + piso + ", letra=" + letra
				+ ", codigoPostal=" + codigoPostal + ", poblacion=" + poblacion + ", provincia=" + provincia;
	}
}
