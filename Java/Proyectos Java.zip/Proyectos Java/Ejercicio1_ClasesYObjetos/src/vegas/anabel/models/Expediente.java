package vegas.anabel.models;

public class Expediente {
	
	public double matematicas;
	public double lengua;
	public double sociales;
	public double plastica;
	
	
	@Override
	public String toString() {
		return "Expediente [matematicas=" + matematicas + ", lengua=" + lengua + ", sociales=" + sociales
				+ ", plastica=" + plastica + "]";
	}
	
}
