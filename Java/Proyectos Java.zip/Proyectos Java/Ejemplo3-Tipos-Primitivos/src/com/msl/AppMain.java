package com.msl;

public class AppMain {

	public static void main(String[] args) {
		
		// Tipos primitivos
		// Enteros
		byte numByte = (byte)7;
		short numShort = (short)19;
		int numInt = 1678;
		long numLong = 6688886756L;
		
		// Reales o decimales
		float numFloat = 5.19F;
		double numDouble = 6789.543;
		
		// Logicos
		boolean booleano = true;
		
		// Texto un solo caracter
		char letra = 'h';
		
		// Recordar que String es una clase, no es un tipo primitivo
		String texto = "Hola";

	}

}
