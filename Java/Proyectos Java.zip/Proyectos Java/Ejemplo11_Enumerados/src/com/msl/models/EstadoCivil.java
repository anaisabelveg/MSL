package com.msl.models;

public enum EstadoCivil {
	
	// Todos los valores de un tipo enumerado se consideran variables estaticas y finales
	SOLTERO, CASADO, VIUDO, DIVORCIADO, PAREJA_HECHO;

}
