package com.msl.main;

import com.msl.models.EstadoCivil;
import com.msl.models.Persona;

public class AppMain {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Persona persona = new Persona("Pepito", 27, EstadoCivil.SOLTERO);
		
		System.out.println(persona);
	}

}
