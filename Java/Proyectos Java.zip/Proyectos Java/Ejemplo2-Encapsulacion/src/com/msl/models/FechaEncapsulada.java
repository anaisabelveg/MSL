package com.msl.models;

// Una clase encapsulada es aquella cuyas propiedades
// son privadas y se accede a ellas a través de los
// metodos getter y setter publicos
public class FechaEncapsulada {
	
	// Variables de instancia
	private int dia;
	private int mes;
	private int anyo;
	
	// Metodos de acceso
	// Accesores
	// Get (lectura) y Set (escritura)
	public int getDia() {
		return dia;
	}

	public void setDia(int dia) {
		// Puntero this que apunta a la instancia
		if (dia < 1 || dia > 31) {
			System.out.println("Dia no valido");
		} else {
			this.dia = dia;
		}		
	}

	public int getMes() {
		return mes;
	}

	public void setMes(int mes) {
		if (mes < 1 || mes > 12 ) {
			System.out.println("Mes no es valido");
		} else {
			this.mes = mes;
		}	
	}

	public int getAnyo() {
		return anyo;
	}

	public void setAnyo(int anyo) {
		if (anyo > 2021) {
			System.out.println("Año no es valido");
		} else {
			this.anyo = anyo;
		}	
	}

	public void mostrarFecha() {
		System.out.println(dia + "/" + mes + "/" + anyo);
	}

}
