package com.msl.main;

import com.msl.models.Fecha;
import com.msl.models.FechaEncapsulada;

public class AppMain {

	public static void main(String[] args) {
		
		Fecha fechaMala = new Fecha();
		fechaMala.dia = 7654;
		fechaMala.mes = -234;
		fechaMala.anyo = 65432;
		
		fechaMala.mostrarFecha();
		
		FechaEncapsulada fechaBuena = new FechaEncapsulada();
		fechaBuena.setDia(7654);
		fechaBuena.setMes(-234);
		fechaBuena.setAnyo(65432);

		fechaBuena.mostrarFecha();
	}

}
