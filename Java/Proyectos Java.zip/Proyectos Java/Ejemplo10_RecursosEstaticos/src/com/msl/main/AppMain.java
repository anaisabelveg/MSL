package com.msl.main;

import com.msl.models.Producto;

public class AppMain {

	public static void main(String[] args) {
		
		Producto producto1 = new Producto("Lampara de mesa", 35);
		Producto producto2 = new Producto("Mesa escritorio", 99.45);
		
		System.out.println(producto1);
		System.out.println(producto2);
		
		//Acceder a un valor almacenado en la instancia
		producto1.getDescripcion();
		
		// Acceder a un recurso estatico
		Producto.getContador();
		
		// Desde la instancia tambien tenemos acceso a los recursos estaticos pero no se recomienda
		producto1.getContador(); 
		
		double numero = Math.PI;
		
		Math.pow(3,6);
		
		
		
	}

}
