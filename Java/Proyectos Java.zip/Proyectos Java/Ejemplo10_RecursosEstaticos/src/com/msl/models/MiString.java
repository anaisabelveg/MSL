package com.msl.models;

// No puedo crear una clase heredando de una clase final
public class MiString extends String{

}
