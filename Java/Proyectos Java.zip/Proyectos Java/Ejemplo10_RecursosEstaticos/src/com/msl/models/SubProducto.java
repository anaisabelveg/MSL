package com.msl.models;

public class SubProducto extends Producto {
	
	@Override
	public double getPrecio() {
		// TODO Auto-generated method stub
		return super.getPrecio();
	}
	
	@Override
	public String getDescripcion() {
		// TODO Auto-generated method stub
		return super.getDescripcion();
	}
	
	// No puedo sobreescribir un metodo final
	@Override
	public int getCodigo() {
		return 12344;
	}
}
