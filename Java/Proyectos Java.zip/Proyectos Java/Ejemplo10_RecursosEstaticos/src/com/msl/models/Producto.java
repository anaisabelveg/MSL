package com.msl.models;

// Una clase final no se puede heredar de ella
public  class Producto {
	
	// Variables de instancia (cada instancia tiene sus propios valores)
	private final int CODIGO; // Constante, una vez que le asignamos un valor no se puede cambiar
	private String descripcion;
	private double precio;
	
	// Variable de clase (solo existe una copia y estara en la clase)
	// Los recursos estaticos comparten valores en todas sus instancias
	private static int contador = 0;
	
	// Constructores
	public Producto() {
		this.CODIGO = ++contador;
	}

	public Producto(String descripcion, double precio) {
		super();
		this.CODIGO = ++contador;
		this.descripcion = descripcion;
		this.precio = precio;
	}

	// Metodo estatico
	public static int getContador() {
		return contador;
	}
	
	// Metodos de instancia
	// Un metodo final no se puede sobreescribir
	public final int getCodigo() {
		return CODIGO;
	}

//	public void setCodigo(int codigo) {
//		this.CODIGO = codigo;
//	}

	public String getDescripcion() {
		return descripcion;
	}

	public void setDescripcion(String descripcion) {
		this.descripcion = descripcion;
	}

	public double getPrecio() {
		return precio;
	}

	public void setPrecio(double precio) {
		this.precio = precio;
	}

	@Override
	public String toString() {
		return "Producto [codigo=" + CODIGO + ", descripcion=" + descripcion + ", precio=" + precio + "]";
	}
	
	

}
