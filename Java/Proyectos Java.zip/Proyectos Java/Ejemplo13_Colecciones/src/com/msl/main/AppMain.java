package com.msl.main;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

public class AppMain {
	
	public static void main(String[] args) {
		
		// Set -> no garantiza el orden de entrada y no permite duplicados
		// List -> SI garantiza el orden de entrada y SI permite duplicados
		
		// Ejemplo de polimorfismo
		Set set = new HashSet();
		set.add(1);
		set.add("Hola");
		set.add(true);
		set.add(6.14);
		
		// Intento guardar un objeto duplicado
		set.add("Hola");
		
		System.out.println(set);
		
		// Todos los elementos de una coleccion se almacenan como Object
		for (Object object : set) {
			System.out.println(object);
			//String texto = (String) object;
			if (object instanceof String) {
				String texto = (String) object;
			}
		}
		
		
		List list = new ArrayList();
		list.add(1);
		list.add("Hola");
		list.add(true);
		list.add(6.14);
		
		// Intento guardar un objeto duplicado
		list.add("Hola");
		
		System.out.println(list);
		
	}

}
