package com.msl.main;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

public class AppMainGenericos {

	public static void main(String[] args) {
		
		Set<String> set = new HashSet<>();
		set.add("Juan");
		set.add("Maria");
		set.add("Pedro");
		// Error de compilacion
		//set.add(345);
		
		for (String dato : set) {
			System.out.println(dato.toUpperCase());
		}
		
		// Los tipos genericos SOLO con clases, no admite tipos primitivos
		//List<int> numeros = new ArrayList<>();
		List<Integer> numeros = new ArrayList<>();
		numeros.add(4); // Autoboxing
		numeros.add(new Integer(8));
		numeros.add(1);
		numeros.add(6);
		
		for (Integer num : numeros) {
			System.out.println(num.intValue());
		}
		
		Map<String, String> emails = new HashMap<>();
		emails.put("Juan", "juan@yahoo.es");
		emails.put("Maria", "maria@gmail.es");
		//Si repito la clave (key) se sobreescribe el value
		emails.put("Maria", "maria@yahoo.es");
		
		System.out.println(emails);
		
		// Obtener el mail de juan
		System.out.println(emails.get("Juan"));
		
		// Mostrar todos los nombres (keys)
		System.out.println(emails.keySet());
		
		// Mostrar solo los emails (Values)
		System.out.println(emails.values());
		
		// Mostrar todos los elementos (key=value)
		System.out.println(emails.entrySet());
		

	}

}
