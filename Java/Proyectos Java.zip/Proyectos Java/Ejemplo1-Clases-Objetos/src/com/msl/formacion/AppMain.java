package com.msl.formacion;

public class AppMain {

	public static void main(String[] args) {

		// Crear un objeto Cliente
		Cliente c = new Cliente();
		

		// Personalizar ese objeto
		c.nombre = "Pepito";
		c.cif = "B-12345678";
		c.cifraVentas = 12789.543;
		c.esVip = true;
		c.direccion = new Direccion();
		
		// Asignar los datos a direccion
		c.direccion.calle = "Gran Via";
		c.direccion.numero = 27;
		c.direccion.piso = 3;
		c.direccion.letra = 'A';
		c.direccion.codigoPostal = 28016;
		c.direccion.poblacion = "Madrid";
		c.direccion.provincia = "Madrid";

		// Invocar al metodo del objeto
		c.mostrarInfo();
		
		// Mostrar el cliente
		System.out.println(c.toString());

	}

}
