package com.msl.formacion;

public class Cliente {

	// propiedades o caracteristicas o campos
	// variables de instancia
	String nombre;
	String cif;
	double cifraVentas;
	boolean esVip;
	Direccion direccion;

	// constructor
	public Cliente() {
		// TODO Auto-generated constructor stub
	}

	// metodos o funciones o acciones
	public void mostrarInfo() {
		System.out.println(
				"Nombre: " + nombre + " Cif: " + cif + 
				" Cifra de ventas: " + cifraVentas + " Es vip: " + esVip +
				" Direccion: " + direccion.toString());
	}

}
