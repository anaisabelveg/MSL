package com.msl.formacion;

// En Java todas las clases heradan directa o indirectamente de la clase Object
// El compilador si la clase no hereda de nadie, agrega extends Object
public class Direccion extends Object{
	
	String calle;
	int numero;
	int piso;
	char letra;
	int codigoPostal;
	String poblacion;
	String provincia;
	
	
	// Elcompilador si no existe ningun constructor agrega el constructor por defecto
	/* 
	 * public Direccion(){}
	*/
	
	@Override
	public String toString() {
		return "calle=" + calle + ", numero=" + numero + ", piso=" + piso + ", letra=" + letra
				+ ", codigoPostal=" + codigoPostal + ", poblacion=" + poblacion + ", provincia=" + provincia;
	}

}
