package com.msl.main;

public class AppMain {

	public static void main(String[] args) {
		// Clases envolventes, clases wrapper
		// byte -> Byte
		// short -> Short
		// int -> Integer
		// long -> Long
		// char -> Character
		// float -> Float
		// double -> Double
		// boolean -> Boolean
		
		int numero = 5;
		Integer numero2 = new Integer(5);
		Float numFloat =  numero2.floatValue();
		
		String texto = "12345";
		int numero3 = Integer.parseInt(texto);
		float numFloat2 = Float.parseFloat(texto);
		
		// Boxing -> Transformar un tipo primitivo en una instancia de su clase wrapper
		Integer numero4 = new Integer(numero);
		
		// Unboxing -> Transformar un objeto de clase wrapper en un tipo primitivo
		int numero5 = numero2.intValue();
		
		// Nuevo a partir de Java 5
		// Autoboxing -> Puedo asignar a una variable de tipo primitivo un objeto y viceversa
		Integer numero6 = 8;
		int numero7 = numero2;

	}

}
