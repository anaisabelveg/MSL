package com.msl.util;

import java.util.Comparator;

import com.msl.models.Alumno;

public class ComparadorNombre implements Comparator<Alumno>{

	@Override
	public int compare(Alumno alum1, Alumno alum2) {
		
		int resultado = alum1.getNombre().compareTo(alum2.getNombre());
		
		if (resultado == 0) {
			return alum1.getCurso()-alum2.getCurso();
		} else {
			return resultado;
		}
	}

}
