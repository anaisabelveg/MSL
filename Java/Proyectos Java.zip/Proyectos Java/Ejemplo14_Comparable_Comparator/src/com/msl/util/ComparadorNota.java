package com.msl.util;

import java.util.Comparator;

import com.msl.models.Alumno;

public class ComparadorNota implements Comparator<Alumno>{

	@Override
	public int compare(Alumno alum1, Alumno alum2) {
		if (alum1.getNota() > alum2.getNota()) {
			return 1;
		} else if (alum1.getNota() < alum2.getNota()) {
			return -1;
		} else {
			// Si retorno 0, no me lo muestra porque serian iguales
			// a cambio devuelvo la ordenacion por nombre
			return alum1.getNombre().compareTo(alum2.getNombre());
		}
	}

}
