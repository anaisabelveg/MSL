package com.msl.models;

public class Alumno {
	
	private String nombre;
	private int curso;
	private double nota;
	
	public Alumno() {
		// TODO Auto-generated constructor stub
	}

	public Alumno(String nombre, int curso, double nota) {
		super();
		this.nombre = nombre;
		this.curso = curso;
		this.nota = nota;
	}

	public String getNombre() {
		return nombre;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	public int getCurso() {
		return curso;
	}

	public void setCurso(int curso) {
		this.curso = curso;
	}

	public double getNota() {
		return nota;
	}

	public void setNota(double nota) {
		this.nota = nota;
	}

	@Override
	public String toString() {
		return "Alumno [nombre=" + nombre + ", curso=" + curso + ", nota=" + nota + "]";
	}
	
	

}
