package com.msl.models;

public class AlumnoComparable implements Comparable<AlumnoComparable>{
	
	private String nombre;
	private int curso;
	private double nota;
	
	public AlumnoComparable() {
		// TODO Auto-generated constructor stub
	}

	public AlumnoComparable(String nombre, int curso, double nota) {
		super();
		this.nombre = nombre;
		this.curso = curso;
		this.nota = nota;
	}
	
	@Override
	public int compareTo(AlumnoComparable otro) {
		// 1 -> si la instancia es mayor que el otro alumno
		// 0 -> si son iguales
		// -1 -> cuando el otro alumno es mayor que la instancia
		
		if (this.nota > otro.nota) {
			return 1;
		} else if (this.nota < otro.nota) {
			return -1;
		} else {
			// Si retorno 0, no me lo muestra porque serian iguales
			// a cambio devuelvo la ordenacion por nombre
			return this.nombre.compareTo(otro.getNombre());
		}
		
	}

	public String getNombre() {
		return nombre;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	public int getCurso() {
		return curso;
	}

	public void setCurso(int curso) {
		this.curso = curso;
	}

	public double getNota() {
		return nota;
	}

	public void setNota(double nota) {
		this.nota = nota;
	}

	@Override
	public String toString() {
		return "Alumno [nombre=" + nombre + ", curso=" + curso + ", nota=" + nota + "]";
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + curso;
		result = prime * result + ((nombre == null) ? 0 : nombre.hashCode());
		long temp;
		temp = Double.doubleToLongBits(nota);
		result = prime * result + (int) (temp ^ (temp >>> 32));
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		AlumnoComparable other = (AlumnoComparable) obj;
		if (curso != other.curso)
			return false;
		if (nombre == null) {
			if (other.nombre != null)
				return false;
		} else if (!nombre.equals(other.nombre))
			return false;
		if (Double.doubleToLongBits(nota) != Double.doubleToLongBits(other.nota))
			return false;
		return true;
	}

	
	
	

}
