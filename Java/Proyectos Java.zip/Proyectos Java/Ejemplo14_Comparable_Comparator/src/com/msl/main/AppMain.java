package com.msl.main;

import java.util.HashSet;
import java.util.Set;
import java.util.TreeSet;

import com.msl.models.Alumno;
import com.msl.models.AlumnoComparable;
import com.msl.util.ComparadorNombre;
import com.msl.util.ComparadorNota;

public class AppMain {

	public static void main(String[] args) {
		
		Set<AlumnoComparable> alumnos = new TreeSet<>();
		alumnos.add(new AlumnoComparable("Juan", 1, 6.3));
		alumnos.add(new AlumnoComparable("Maria", 2, 6.3));
		alumnos.add(new AlumnoComparable("Pedro", 3, 3.8));
		alumnos.add(new AlumnoComparable("Laura", 4, 9.6));
		alumnos.add(new AlumnoComparable("Noelia", 1, 5.1));
		alumnos.add(new AlumnoComparable("Sofia", 2, 7.3));
		
		for (AlumnoComparable alumno : alumnos) {
			System.out.println(alumno);
		}
		
		System.out.println("----------------------");
		//Set<Alumno> alumnosNombre = new TreeSet<>(new ComparadorNombre());
		Set<Alumno> alumnosNombre = new TreeSet<>(new ComparadorNota());
		alumnosNombre.add(new Alumno("Juan", 1, 6.3));
		alumnosNombre.add(new Alumno("Maria", 2, 6.4));
		alumnosNombre.add(new Alumno("Pedro", 3, 3.8));
		alumnosNombre.add(new Alumno("Laura", 4, 9.6));
		alumnosNombre.add(new Alumno("Laura", 1, 5.1));
		alumnosNombre.add(new Alumno("Sofia", 2, 7.3));
		
		for (Alumno alumno : alumnosNombre) {
			System.out.println(alumno);
		}

	}

}





