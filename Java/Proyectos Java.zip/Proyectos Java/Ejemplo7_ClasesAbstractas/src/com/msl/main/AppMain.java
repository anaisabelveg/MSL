package com.msl.main;

import com.msl.models.Circulo;
import com.msl.models.Figura;
import com.msl.models.Rectangulo;

public class AppMain {

	public static void main(String[] args) {
		Rectangulo rectangulo = new Rectangulo(5, 7, 9, 3);
		System.out.println("Area del rectangulo: " + rectangulo.calcularArea());
		
		Circulo circulo = new Circulo(2, 5, 10);
		System.out.println("Area del circulo: " + circulo.calcularArea());
		
		// Puedo utilizar la clase abstracta como tipo pero no puedo crear objetos
		//Figura figura = new Figura(3,8);

	}

}
