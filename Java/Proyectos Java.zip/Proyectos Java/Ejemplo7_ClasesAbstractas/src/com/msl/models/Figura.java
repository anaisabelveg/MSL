package com.msl.models;

// Si la clase tiene un metodo abstracto se tiene que declarar como abstracta
public abstract class Figura {
	
	private double coordenadaX;
	private double coordenadaY;
	
	public Figura() {
	}

	public Figura(double coordenadaX, double coordenadaY) {
		super();
		this.coordenadaX = coordenadaX;
		this.coordenadaY = coordenadaY;
	}
	
	// El algoritmo depende de la figura
	// Un metodo abstracto es un metodo declarado pero no implementado , sin {}
	public abstract double calcularArea();

	public double getCoordenadaX() {
		return coordenadaX;
	}

	public void setCoordenadaX(double coordenadaX) {
		this.coordenadaX = coordenadaX;
	}

	public double getCoordenadaY() {
		return coordenadaY;
	}

	public void setCoordenadaY(double coordenadaY) {
		this.coordenadaY = coordenadaY;
	}

	@Override
	public String toString() {
		return "[" + coordenadaX + ", " + coordenadaY + "]";
	}
	
	

}
