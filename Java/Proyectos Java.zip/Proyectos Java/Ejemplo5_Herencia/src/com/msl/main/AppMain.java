package com.msl.main;

import com.msl.models.Director;

public class AppMain {

	public static void main(String[] args) {
		
		Director director = new Director();
		director.setNombre("Pepito");
		director.setSueldo(60000);
		director.setDepartamento("Marketing");
		director.setBonus(20000);
		director.setCoche("1234-LHG");
		
		System.out.println(director.toString());
		
		
		Director director2 = new Director("Maria", 70000, "Ventas", 35000, "9876-LDM");
		System.out.println(director2);

	}

}
