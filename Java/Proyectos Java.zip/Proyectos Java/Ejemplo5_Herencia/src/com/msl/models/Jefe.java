package com.msl.models;

public class Jefe extends Empleado {
	
	private String departamento;
	
	public Jefe() {
		super();
		System.out.println("Construyento el objeto jefe");
	}
	
	
	
	public Jefe(String nombre, double sueldo, String departamento) {
		super(nombre, sueldo);
		this.departamento = departamento;
	}



	public String getDepartamento() {
		return departamento;
	}
	
	public void setDepartamento(String departamento) {
		this.departamento = departamento;
	}

	@Override
	public String toString() {
		return "Jefe [departamento=" + departamento + ", toString()=" + super.toString() + "]";
	}

	

//	@Override
//	public String toString() {
//		return "Jefe [" + super.toString() + "departamento=" + departamento + "]";
//	}

	
	
	

}
