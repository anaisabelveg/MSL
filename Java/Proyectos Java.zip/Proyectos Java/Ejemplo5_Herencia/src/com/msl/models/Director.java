package com.msl.models;

public class Director extends Jefe {

	private double bonus;
	private String coche;
	
	public Director() {
		// Por defecto el compilador añade la llamada super()
		super(); // Solo se puede utilizar en el constructor y debe ser la primera linea
		System.out.println("Construyendo el objeto director");
	}
	
	

	public Director(String nombre, double sueldo, String departamento, double bonus, String coche) {
		super(nombre, sueldo, departamento);
		this.bonus = bonus;
		this.coche = coche;
	}



	public double getBonus() {
		return bonus;
	}

	public void setBonus(double bonus) {
		this.bonus = bonus;
	}

	public String getCoche() {
		return coche;
	}

	public void setCoche(String coche) {
		this.coche = coche;
	}

	@Override
	public String toString() {
		return "Director [" +  super.toString() + "bonus=" + bonus + ", coche=" + coche + "]";
	}
	
	

}
