package ejercicio2;

public class Main {

    public static void main(String[] args) {
        int numero = 5;
        float decimal = 5.4F;
        char letra = 'b';
        double num = 2.44;
        boolean booleano = false;
        String palabra = "hola";
        System.out.println("Numero: " + numero + " Letra: " + letra + " palabra: " + palabra);
        System.out.println("Decimal: " + decimal + " booleano: " + booleano + " " + "Double" + num);
    }
}
