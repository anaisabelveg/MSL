package ejercicio3;

public class TestPersona {

    public static void main(String[] args) {

        Persona objPersona = new Persona();
        objPersona.calcularEdad(15);
        objPersona.calcularEdad(42);
        objPersona.calcularEdad(84);
    }

}
