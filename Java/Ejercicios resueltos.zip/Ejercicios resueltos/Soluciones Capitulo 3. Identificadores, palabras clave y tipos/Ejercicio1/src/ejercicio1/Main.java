package ejercicio1;

public class Main {

    public static void main(String[] args) {
        Monedas objMonedas = new Monedas();
        objMonedas.calcularCambio(200, 163.27 );
    }

}
