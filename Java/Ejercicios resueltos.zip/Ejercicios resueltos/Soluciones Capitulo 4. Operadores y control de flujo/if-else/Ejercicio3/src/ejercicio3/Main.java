package ejercicio3;

public class Main {

    public static void main(String[] args) {
        int x = 15;
        int y = 9;
        int z = 8;
        if (x > y && x > z) {
            System.out.println("El mayor es " + x);
        } else if (y > x && y > z) {
            System.out.println("El mayor es " + y);
        } else {
            System.out.println("El mayor es " + z);
        }
    }
}
