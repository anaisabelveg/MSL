package ejercicio2;

public class Main {

    public static void main(String[] args) {
        int x = 15;
        int y = 8;
        if (x > y) {
            System.out.println("El numero x = " + x + " es mayor que y = " + y);
        } else if (x < y) {
            System.out.println("El numero x = " + x + " es menor que y = " + y);
        } else {
            System.out.println("Ambos numeros son iguales");
        }
    }
}
