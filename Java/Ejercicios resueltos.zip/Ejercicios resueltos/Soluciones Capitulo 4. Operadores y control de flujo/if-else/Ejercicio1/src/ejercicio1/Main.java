package ejercicio1;

public class Main {

    public static void main(String[] args) {
        int numero = 6;

        if (numero % 2 == 0){
            System.out.println("El numero " + numero + " es par");
        }else{
            System.out.println("El numero " + numero + " es impar");
        }
    }

}
