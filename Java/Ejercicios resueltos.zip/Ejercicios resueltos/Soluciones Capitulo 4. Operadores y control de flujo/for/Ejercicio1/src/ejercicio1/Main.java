package ejercicio1;

public class Main {

    public static void main(String[] args) {

        System.out.println("Numeros ascendentes");
        for (int i=1; i<=10; i=i+1){
            System.out.println(i);
        }

        System.out.println("Numeros descendentes");
	for (int i=10; i>0; i=i-1){
            System.out.println(i);
        }
    }

}
