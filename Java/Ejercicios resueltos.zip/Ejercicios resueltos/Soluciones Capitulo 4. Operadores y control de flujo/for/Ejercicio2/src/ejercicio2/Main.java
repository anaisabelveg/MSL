package ejercicio2;

public class Main {

    public static void main(String[] args) {
        for (int i = 1990; i <= 2007; i++) {
            System.out.println("Feliz Navidad " + i);
        }
    }
}
