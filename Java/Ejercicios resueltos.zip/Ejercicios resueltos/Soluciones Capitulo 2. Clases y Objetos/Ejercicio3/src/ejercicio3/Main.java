package ejercicio3;

public class Main {

    public static void main(String[] args) {
       Areas objAreas = new Areas();
       objAreas.areaCirculo(67.23);
       objAreas.areaRectangulo(23, 78);
    }

}
