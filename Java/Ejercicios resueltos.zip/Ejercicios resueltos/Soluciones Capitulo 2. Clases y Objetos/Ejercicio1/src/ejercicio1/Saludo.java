package ejercicio1;

public class Saludo {

    public void saludar(){
        System.out.println("Bienvenidos al curso de Java");
    }

}
