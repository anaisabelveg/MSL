package ejercicio1;

public class Main {

    public static void main(String[] args) {
        Saludo objSaludo = new Saludo();
        objSaludo.saludar();
    }

}
