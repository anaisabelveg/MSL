package ejercicio3;

public class Main {

    public static void main(String[] args) {

        String [] miArray = {"uno", "dos", "tres", "cuatro", "cinco", "seis"};

        for (int i = miArray.length - 1; i >= 0; i--){
            System.out.println(miArray[i]);
        }
    }

}
