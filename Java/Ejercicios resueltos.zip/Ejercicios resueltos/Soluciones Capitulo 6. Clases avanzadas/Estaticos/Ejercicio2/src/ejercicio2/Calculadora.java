package ejercicio2;

public class Calculadora {

        public static int suma(int n1, int n2){
		return n1 + n2;
	}

	public static int resta(int n1, int n2){
		return n1 - n2;
	}

        public static int multiplica(int n1, int n2){
		return n1 * n2;
	}

        public static int divide(int n1, int n2){
		return n1 / n2;
	}
}