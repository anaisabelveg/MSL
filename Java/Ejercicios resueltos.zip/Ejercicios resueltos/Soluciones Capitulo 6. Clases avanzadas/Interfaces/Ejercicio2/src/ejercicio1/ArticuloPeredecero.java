package ejercicio1;

public interface ArticuloPeredecero {

    public void caducar();

}
