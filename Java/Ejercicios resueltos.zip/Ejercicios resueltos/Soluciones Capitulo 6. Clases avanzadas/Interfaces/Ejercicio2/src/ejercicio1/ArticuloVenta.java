package ejercicio1;

public interface ArticuloVenta {

    float getPrecio();
    String getProveedor();

}
