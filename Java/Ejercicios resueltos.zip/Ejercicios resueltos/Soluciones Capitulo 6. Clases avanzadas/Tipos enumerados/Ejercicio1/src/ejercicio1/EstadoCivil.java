package ejercicio1;

public enum EstadoCivil {
    SOLTERO, CASADO, VIUDO, DIVORCIADO;
}
