package ejercicio2;

public class Gorrion extends Pajaro{

}
