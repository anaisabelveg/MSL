package ejercicio2;

public class Buitre extends Pajaro{

}
