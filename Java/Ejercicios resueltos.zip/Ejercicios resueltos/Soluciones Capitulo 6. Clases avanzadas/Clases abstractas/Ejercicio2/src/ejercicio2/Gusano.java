package ejercicio2;

public class Gusano extends Animal{

    @Override
    public void comer() {
        System.out.println("El gusano come");
    }

    @Override
    public void moverse() {
        System.out.println("El gusano se mueve");
    }

}
