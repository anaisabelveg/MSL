package ejercicio2;

public abstract class Animal {

    public abstract void comer();

    public abstract void moverse();

}
