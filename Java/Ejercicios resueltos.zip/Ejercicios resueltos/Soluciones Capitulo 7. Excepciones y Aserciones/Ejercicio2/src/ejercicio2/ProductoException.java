package ejercicio2;

public class ProductoException extends Exception{

    public ProductoException(String message) {
        super(message);
    }

}
