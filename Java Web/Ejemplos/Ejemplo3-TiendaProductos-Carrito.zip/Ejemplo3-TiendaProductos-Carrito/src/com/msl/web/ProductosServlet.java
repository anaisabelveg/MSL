package com.msl.web;

import java.io.IOException;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.msl.modelos.Producto;
import com.msl.negocio.Carrito;
import com.msl.negocio.ItfzNegocioProductos;
import com.msl.negocio.NegocioProductos;

/**
 * Servlet implementation class ProductosServlet
 */
@WebServlet("/servlet")
public class ProductosServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	ItfzNegocioProductos negocio = new NegocioProductos();

	public ProductosServlet() {
		super();
		// TODO Auto-generated constructor stub
	}

	private String procesarTodos(HttpServletRequest request, HttpServletResponse response) {
		List<Producto> productos = negocio.consultarTodos();

		// Guardamos la lista de productos como atributo de la peticion
		request.setAttribute("lista", productos);

		return "/mostrarTodos.jsp";
	}
	
	private String procesarBusqueda(HttpServletRequest request, HttpServletResponse response) {
		int id = Integer.parseInt(request.getParameter("codigo"));
		Producto producto = negocio.buscar(id);
		request.setAttribute("encontrado", producto);
		return "/mostrarProducto.jsp";
	}
	
	private String procesarAlta(HttpServletRequest request, HttpServletResponse response) {
		int id = Integer.parseInt(request.getParameter("codigo"));
		String descripcion = request.getParameter("descripcion");
		double precio = Double.parseDouble(request.getParameter("precio"));
		
		boolean insertado = negocio.insertarNuevo(new Producto(id, descripcion, precio));
		if (insertado) {
			request.setAttribute("mensaje", "Producto insertado en la BBDD correctamente");
		} else {
			request.setAttribute("mensaje", "No se pudo insertar el producto en la BBDD");
		}
		
		return "/mostrarMensaje.jsp";
	}

	private String procesarEliminar(HttpServletRequest request, HttpServletResponse response) {
		int id = Integer.parseInt(request.getParameter("codigo"));
		boolean eliminado = negocio.eliminarProducto(id);
		if (eliminado) {
			request.setAttribute("mensaje", "Producto eliminado de la BBDD correctamente");
		} else {
			request.setAttribute("mensaje", "No se pudo eliminar el producto de la BBDD");
		}
		return "/mostrarMensaje.jsp";
	}
	
	private String procesarModificar(HttpServletRequest request, HttpServletResponse response) {
		int id = Integer.parseInt(request.getParameter("codigo"));
		double precio = Double.parseDouble(request.getParameter("precio"));
		boolean modificado = negocio.modificarPrecio(id, precio);
		if (modificado) {
			request.setAttribute("mensaje", "Producto modificado de la BBDD correctamente");
		} else {
			request.setAttribute("mensaje", "No se pudo modificar el producto de la BBDD");
		}
		return "/mostrarMensaje.jsp";
	}
	
	private String procesarCompra(HttpServletRequest request, HttpServletResponse response) {
		// Recuperar el codigo del producto
		int id = Integer.parseInt(request.getParameter("codigo"));
		
		// Recuperar la session del usuario. Si no existe session se crea
		// true -> si no existe la session la crea. Es lo mismo que getSession()
		// false -> si no existe la sesion NO la crea.
		HttpSession miSession = request.getSession(true);
		
		// Agregamos un nuevo carrito a esa session nueva o recuperar el carrito de la session existente
		Carrito carrito = (Carrito) miSession.getAttribute("miCarro");
		if (carrito == null) {
			carrito = new Carrito();
			miSession.setAttribute("miCarro", carrito);
		}
		
		// Agregamos el producto al carrito
		carrito.addProducto(id);
		
		// Devolvemos la vista
		return "/mostrarCarrito.jsp";
	}
	
	private String procesarSacarProducto(HttpServletRequest request, HttpServletResponse response) {
		// Recuperar el codigo del producto
		int id = Integer.parseInt(request.getParameter("codigo"));
		
		// Recuperar la session del usuario que debe de existir
		// true -> si no existe la session la crea. Es lo mismo que getSession()
		// false -> si no existe la sesion NO la crea.
		HttpSession miSession = request.getSession(false);
		
		// Agregamos un nuevo carrito a esa session nueva o recuperar el carrito de la session existente
		Carrito carrito = (Carrito) miSession.getAttribute("miCarro");
		
		// Agregamos el producto al carrito
		carrito.sacarProducto(id);
		
		// Devolvemos la vista
		return "/mostrarCarrito.jsp";
	}
	
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		String vista = "/index.html";

		switch (request.getParameter("op")) {
			case "1": // consultar todos
				vista = procesarTodos(request, response);
				break;
	
			case "2": // buscar un producto
				vista = procesarBusqueda(request, response);
				break;
	
			case "3": // alta producto
				vista = procesarAlta(request, response);
				break;
	
			case "4": // eliminar producto
				vista = procesarEliminar(request, response);
				break;
	
			case "5": // modificar producto
				vista = procesarModificar(request, response);
				break;
	
			case "6": // comprar producto
				vista = procesarCompra(request, response);
				break;
	
			case "7": // sacar producto del carrito
				vista = procesarSacarProducto(request, response);
				break;
	
			default:
				break;
		}

		// Elegir la vista que mostrara el resultado
		RequestDispatcher rd = request.getRequestDispatcher(vista);

		// Redigir hacia esa pagina
		rd.forward(request, response);

	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
