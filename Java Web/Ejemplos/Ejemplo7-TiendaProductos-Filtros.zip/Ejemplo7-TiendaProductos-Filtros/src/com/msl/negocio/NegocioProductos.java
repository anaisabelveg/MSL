package com.msl.negocio;

import java.util.List;

import com.msl.modelos.Producto;
import com.msl.persistencia.ItfzProductosDAO;
import com.msl.persistencia.ProductosDAO;

public class NegocioProductos implements ItfzNegocioProductos {
	
	ItfzProductosDAO dao = new ProductosDAO();
	
	@Override
	public List<Producto> consultarTodos() {
		return dao.consultarTodos();
	}

	@Override
	public boolean insertarNuevo(Producto nuevo) {
		return dao.insertarNuevo(nuevo);
	}

	@Override
	public Producto buscar(int id) {
		return dao.buscar(id);
	}

	@Override
	public boolean eliminarProducto(int id) {
		return dao.eliminarProducto(id);
	}

	@Override
	public boolean modificarPrecio(int id, double nuevoPrecio) {
		return dao.modificarPrecio(id, nuevoPrecio);
	}

}
