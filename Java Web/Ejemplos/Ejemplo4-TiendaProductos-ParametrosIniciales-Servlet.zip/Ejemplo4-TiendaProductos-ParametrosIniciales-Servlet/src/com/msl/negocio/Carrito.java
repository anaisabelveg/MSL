package com.msl.negocio;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import com.msl.modelos.Producto;

// Todo lo que se guarde en una session debe ser Serializable
// Serializable es una interface de marca. No hay que implementar ningun metodo
public class Carrito implements Serializable {
	
	
	/**
	 * 
	 */
	private static final long serialVersionUID = -6927176239806303587L;
	private double importe;
	private List<Producto> contenido = new ArrayList<>();
	private ItfzNegocioProductos negocio = new NegocioProductos();
	
	public void addProducto(int id) {
		Producto encontrado = negocio.buscar(id);
		contenido.add(encontrado);
		importe += encontrado.getPrecio();
	}
	
	public void sacarProducto(int id) {
		Producto eliminar = null;
		for (Producto producto : contenido) {
			if (id == producto.getId()) {
				eliminar = producto;
			}
		}
		contenido.remove(eliminar);
		importe -= eliminar.getPrecio();
	}
	
	// Clases idempotentes -> solo tienen metodos get
	public double getImporte() {
		return importe;
	}
	
	public List<Producto> getContenido() {
		return contenido;
	}

}
