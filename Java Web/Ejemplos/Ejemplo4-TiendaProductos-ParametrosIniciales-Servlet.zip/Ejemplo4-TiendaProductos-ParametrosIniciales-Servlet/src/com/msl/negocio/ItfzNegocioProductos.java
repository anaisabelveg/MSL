package com.msl.negocio;

import java.util.List;

import com.msl.modelos.Producto;

public interface ItfzNegocioProductos {

	List<Producto> consultarTodos();

	boolean insertarNuevo(Producto nuevo);

	Producto buscar(int id);

	boolean eliminarProducto(int id);

	boolean modificarPrecio(int id, double nuevoPrecio);
}
